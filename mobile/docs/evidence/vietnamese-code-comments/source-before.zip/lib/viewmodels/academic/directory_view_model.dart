import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/academic/academic_models.dart';
import 'academic_view_model.dart';
import '../../app/session.dart';
import '../../models/academic/academic_projections.dart';

final studentDirectoryProvider =
    NotifierProvider.autoDispose<StudentDirectoryViewModel, AcademicRecord>(
      StudentDirectoryViewModel.new,
    );

class StudentDirectoryViewModel extends Notifier<AcademicRecord> {
  @override
  AcademicRecord build() {
    ref.watch(sessionScopeProvider);
    return AcademicRecord({
      'semester': '',
      'course': '',
      'class': '',
      'query': '',
    });
  }

  AcademicSnapshot get snapshot =>
      ref.read(academicViewModelProvider).requireValue;
  void set(String key, String value) => state = AcademicRecord({
    ...state.toJson(),
    key: value,
    if (key == 'semester') 'course': '',
    if (key == 'semester' || key == 'course') 'class': '',
  });
  void clear() => state = build();
  List<ClassRoom> get classes => snapshot.classes
      .where(
        (c) =>
            (state.text('semester').isEmpty ||
                c.semesterId == state.text('semester')) &&
            (state.text('course').isEmpty ||
                c.courseId == state.text('course')),
      )
      .toList();
  List<Course> get courses => snapshot.courses
      .where(
        (c) =>
            state.text('semester').isEmpty ||
            snapshot.classes.any(
              (cls) =>
                  cls.semesterId == state.text('semester') &&
                  cls.courseId == c.id,
            ),
      )
      .toList();
  List<AcademicStudent> get visible {
    final ids = classes
        .where(
          (c) => state.text('class').isEmpty || c.id == state.text('class'),
        )
        .map((c) => c.id)
        .toSet();
    final q = state.text('query').trim().toLowerCase();
    return snapshot.students
        .where(
          (s) =>
              ids.contains(s.text('classId')) &&
              (q.isEmpty ||
                  [
                    s.name,
                    s.studentCode,
                    s.text('email'),
                  ].any((v) => v.toLowerCase().contains(q))),
        )
        .toList();
  }

  int get groupedCount =>
      AcademicProjections.groupedStudents(visible, snapshot.groups);
}

extension SemesterCommands on AcademicViewModel {
  List<AcademicSemester> get orderedSemesters =>
      AcademicProjections.semesters(snapshot);
  Future<void> saveSemester(AcademicJson input) => mutate((s) {
    final start = DateTime.tryParse(input['startDate']?.toString() ?? '');
    final end = DateTime.tryParse(input['endDate']?.toString() ?? '');
    final name = input['name']?.toString().trim() ?? '';
    final year = input['academicYear']?.toString().trim() ?? '';
    if (name.isEmpty ||
        year.isEmpty ||
        start == null ||
        end == null ||
        !end.isAfter(start)) {
      throw const AcademicFailure(
        'Nhập tên, năm học và ngày kết thúc sau ngày bắt đầu.',
      );
    }
    final id = input['id']?.toString() ?? '';
    final old = s.semester(id);
    if (id.isNotEmpty && old == null) {
      throw const AcademicFailure('Không tìm thấy học kỳ.');
    }
    return s.replaceCollection(
      'semesters',
      upsert(s, 'semesters', {
        ...?old?.toJson(),
        'id': old?.id ?? nextId('semester'),
        'name': name,
        'academicYear': year,
        'startDate': input['startDate'],
        'endDate': input['endDate'],
        'description': input['description']?.toString().trim() ?? '',
        'archived': old?.archived ?? false,
      }),
    );
  });
  Future<void> archiveSemester(String id, bool archived) => mutate((s) {
    final old = s.semester(id);
    if (old == null) throw const AcademicFailure('Không tìm thấy học kỳ.');
    return s.replaceCollection(
      'semesters',
      upsert(s, 'semesters', {...old.toJson(), 'archived': archived}),
    );
  });
  Future<void> deleteSemester(String id) => mutate((s) {
    if (s.semester(id) == null) {
      throw const AcademicFailure('Không tìm thấy học kỳ.');
    }
    if (s.classes.any((c) => c.semesterId == id) ||
        s.offerings.any((o) => o.semesterId == id)) {
      throw const AcademicFailure(
        'Học kỳ có lớp hoặc đợt học. Hãy lưu trữ để giữ liên kết.',
      );
    }
    return s.replaceCollection('semesters', [
      for (final sem in s.semesters)
        if (sem.id != id) sem.toJson(),
    ]);
  });
}

String semesterPhase(AcademicSemester s, int now) {
  return AcademicProjections.semesterPhase(s, now);
}
