import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/academic/academic_models.dart';
import '../../app/providers.dart';
import 'academic_view_model.dart';
import '../../app/session.dart';

final studentEnrollmentProvider = NotifierProvider.autoDispose
    .family<StudentEnrollmentViewModel, EnrollmentState, String>(
      StudentEnrollmentViewModel.new,
    );

/// Bản nháp thêm sinh viên; hủy modal không ghi danh hoặc thay đổi danh sách lớp.
class EnrollmentState {
  const EnrollmentState({
    this.tab = 0,
    this.q = '',
    this.selected = const {},
    this.rows = const [],
    this.fileName = '',
    this.error = '',
    this.busy = false,
  });
  final int tab;
  final String q, fileName, error;
  final Set<String> selected;
  final List<AcademicJson> rows;
  final bool busy;
  EnrollmentState copy({
    int? tab,
    String? q,
    Set<String>? selected,
    List<AcademicJson>? rows,
    String? fileName,
    String error = '',
    bool? busy,
  }) => EnrollmentState(
    tab: tab ?? this.tab,
    q: q ?? this.q,
    selected: selected ?? this.selected,
    rows: rows ?? this.rows,
    fileName: fileName ?? this.fileName,
    error: error,
    busy: busy ?? this.busy,
  );
}

/// Parse/kiểm tra CSV và chọn danh bạ ở ViewModel, ghi batch qua kho học vụ.
class StudentEnrollmentViewModel extends Notifier<EnrollmentState> {
  StudentEnrollmentViewModel(this.classId);
  final String classId;
  AcademicSnapshot get snapshot =>
      ref.read(academicViewModelProvider).requireValue;
  @override
  EnrollmentState build() {
    ref.watch(sessionScopeProvider);
    return const EnrollmentState();
  }

  void tab(int value) => state = state.copy(tab: value);
  void query(String value) => state = state.copy(q: value);
  void select(String id) {
    final selected = {...state.selected};
    selected.contains(id) ? selected.remove(id) : selected.add(id);
    state = state.copy(selected: selected);
  }

  List<AcademicRecord> get candidates {
    final codes = snapshot
        .classStudents(classId)
        .map((s) => s.studentCode)
        .toSet();
    return snapshot
        .records('directoryStudents')
        .where(
          (s) =>
              !codes.contains(s.text('studentCode')) &&
              '${s.name} ${s.text('studentCode')} ${s.text('email')}'
                  .toLowerCase()
                  .contains(state.q.toLowerCase()),
        )
        .take(8)
        .toList();
  }

  List<AcademicJson> validate(List<AcademicJson> rows) {
    final seen = snapshot
        .classStudents(classId)
        .map((s) => s.studentCode)
        .toSet();
    return rows.map((r) {
      final code = r['studentCode']?.toString().trim().toUpperCase() ?? '';
      final name = r['name']?.toString().trim() ?? '';
      final email = r['email']?.toString().trim() ?? '';
      final status = code.isEmpty || name.isEmpty || email.isEmpty
          ? 'missing'
          : !RegExp(r'^[A-Z]{2}\d{6}$').hasMatch(code) || !email.contains('@')
          ? 'format'
          : seen.contains(code)
          ? 'exists'
          : 'valid';
      seen.add(code);
      return {
        'studentCode': code,
        'name': name,
        'email': email,
        'status': status,
      };
    }).toList();
  }

  void loadCsv(String csv, String name) {
    var lines = csv
        .split(RegExp(r'\r?\n'))
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();
    if (lines.isNotEmpty &&
        RegExp(r'mã|code', caseSensitive: false).hasMatch(lines.first)) {
      lines = lines.skip(1).toList();
    }
    state = state.copy(
      fileName: name,
      rows: validate(
        lines.take(500).map((l) {
          final parts = l
              .split(RegExp(r'[,;\t]'))
              .map((v) => v.trim())
              .toList();
          return {
            'studentCode': parts.firstOrNull ?? '',
            'name': parts.length > 1 ? parts[1] : '',
            'email': parts.length > 2 ? parts[2] : '',
          };
        }).toList(),
      ),
    );
  }

  /// XLSX của Lab 2 chỉ xem dữ liệu mẫu; không giả là bộ đọc spreadsheet thật.
  void sample([String name = 'danh-sach-SE1701.xlsx']) => state = state.copy(
    fileName: name,
    rows: validate([
      ...snapshot.records('studentImportSample').map((r) => r.toJson()),
      ...snapshot.classStudents(classId).take(2).map((s) => s.toJson()),
    ]),
  );
  Future<void> pick() async {
    final scope = ref.read(sessionScopeProvider);
    try {
      final file = await ref.read(studentImportServiceProvider).pick();
      if (!ref.mounted || !scope.active || file == null) return;
      file.csv == null ? sample(file.name) : loadCsv(file.csv!, file.name);
    } catch (e) {
      if (ref.mounted && scope.active) {
        state = state.copy(error: 'Không đọc được tệp. Chọn lại CSV UTF-8.');
      }
    }
  }

  Future<void> copy(String value) =>
      ref.read(studentImportServiceProvider).copy(value);
  Future<void> regenerate() =>
      ref.read(academicViewModelProvider.notifier).regenerateQr(classId);
  Future<bool> save() async {
    final scope = ref.read(sessionScopeProvider);
    if (state.busy) return false;
    state = state.copy(busy: true);
    try {
      final rows = state.tab == 1
          ? state.rows.where((r) => r['status'] == 'valid').toList()
          : snapshot
                .records('directoryStudents')
                .where(
                  (r) => state.selected.contains(
                    r.id.isEmpty ? r.text('studentCode') : r.id,
                  ),
                )
                .map((r) => r.toJson())
                .toList();
      if (rows.isEmpty) {
        throw const AcademicFailure('Chọn sinh viên hợp lệ trước khi thêm.');
      }
      await ref
          .read(academicViewModelProvider.notifier)
          .enrollStudents(classId, rows);
      if (ref.mounted && scope.active) state = state.copy(busy: false);
      return scope.active;
    } catch (e) {
      if (ref.mounted && scope.active) {
        state = state.copy(
          busy: false,
          error: e is AcademicFailure
              ? e.message
              : 'Không thể thêm sinh viên. Vui lòng thử lại.',
        );
      }
      return false;
    }
  }
}
