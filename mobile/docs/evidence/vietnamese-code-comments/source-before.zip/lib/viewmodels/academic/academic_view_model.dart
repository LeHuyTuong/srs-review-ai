import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/providers.dart';
import '../../models/academic/academic_models.dart';
import '../../models/academic/academic_policy.dart';
import '../dashboard/dashboard_view_model.dart';
import 'management_actions.dart';
import '../../app/session.dart';
import '../../models/session_scope.dart';
import '../../repositories/academic/course_contract.dart';

final academicViewModelProvider =
    AsyncNotifierProvider<AcademicViewModel, AcademicSnapshot>(
      AcademicViewModel.new,
      retry: (n, e) => null,
    );

/// State học vụ chung; lệnh ghi kiểm tra phạm vi trước khi commit toàn snapshot.
class AcademicViewModel extends AsyncNotifier<AcademicSnapshot> {
  AcademicSnapshot get snapshot => state.requireValue;

  /// Phân biệt tác vụ AI đang chạy với bản loading bị gián đoạn để cho phép retry.
  final Set<String> activeEvaluationIds = {};
  bool _writing = false;
  int _sequence = 0;
  late SessionScope sessionScope;
  @override
  Future<AcademicSnapshot> build() {
    sessionScope = ref.watch(sessionScopeProvider);
    activeEvaluationIds.clear();
    _writing = false;
    return ref.watch(academicRepositoryProvider).load();
  }

  String nextId(String prefix) =>
      '$prefix-${DateTime.now().microsecondsSinceEpoch}-${_sequence++}';
  void retry() => ref.invalidateSelf();

  /// Nhân bản chỉ tạo bản nháp để chỉnh; hủy editor không thêm rule vào thư viện.
  AcademicJson cloneRuleDraft(RuleSet rule) => {
    ...rule.toJson(),
    'id': nextId('rule'),
    'name': '${rule.name} (bản sao)',
    'status': 'draft',
    'version': 1,
  };

  /// Mutation lỗi giữ nguyên dữ liệu đang xem; chặn double-submit và state sau dispose.
  Future<void> mutate(
    AcademicSnapshot Function(AcademicSnapshot) change, {
    CourseMutation? courseCommand,
  }) async {
    final operationScope = sessionScope;
    operationScope.requireActive();
    if (_writing) {
      throw const AcademicFailure('Đang lưu dữ liệu. Vui lòng chờ.');
    }
    final old = state.requireValue;
    _writing = true;
    try {
      final candidate = change(old);
      final repository = ref.read(academicRepositoryProvider);
      final next =
          courseCommand != null && repository is CourseCommandRepository
          ? await (repository as CourseCommandRepository).commitCourse(
              courseCommand,
              expectedRevision: old.revision,
            )
          : await repository.commit(candidate, expectedRevision: old.revision);
      if (ref.mounted && operationScope.active) {
        state = AsyncData(next);
        ref.invalidate(dashboardViewModelProvider);
      }
    } finally {
      if (operationScope.active) _writing = false;
    }
  }

  List<AcademicJson> upsert(AcademicSnapshot s, String key, AcademicJson v) => [
    for (final r in s.records(key))
      if (r.id == v['id']) v else r.toJson(),
    if (!s.records(key).any((r) => r.id == v['id'])) v,
  ];
  ClassRoom activeClass(AcademicSnapshot s, String id) {
    final cls = s.classRoom(id);
    if (cls == null) throw const AcademicFailure('Không tìm thấy lớp.');
    if (cls.archived) {
      throw const AcademicFailure(
        'Lớp đã lưu trữ. Khôi phục lớp trước khi chỉnh sửa.',
      );
    }
    return cls;
  }

  Future<void> saveCourse(AcademicJson input) async {
    final draft = CourseDto.fromJson(
      input,
      requireId: false,
      errorCode: AcademicErrorCode.validation,
    );
    final command = CourseMutation(
      course: draft,
      id: draft.id.isEmpty ? nextId('course') : draft.id,
      create: draft.id.isEmpty,
    );
    await mutate(command.apply, courseCommand: command);
  }

  /// Đợt mới dùng rule active và bản sao Lab đợt trước; sửa đợt không đổi override lớp.
  Future<void> saveOffering(AcademicJson input) => mutate((s) {
    final course = s.course(input['courseId'] as String);
    final sem = s.semester(input['semesterId'] as String);
    if (course == null || sem == null) {
      throw const AcademicFailure('Chọn môn học và học kỳ hợp lệ.');
    }
    if (s.rule(input['ruleSetId'] as String)?.active != true) {
      throw const AcademicFailure(
        'Chọn bộ quy tắc Đang áp dụng trước khi lưu.',
      );
    }
    final old = s.offering(input['id'] as String? ?? '');
    final v = {
      ...?old?.toJson(),
      ...input,
      'id': old?.id ?? nextId('off'),
      'defaultDeadline': input['defaultDeadline']?.toString().isNotEmpty == true
          ? input['defaultDeadline']
          : old?.deadline ?? '${sem.endDate}T23:59',
      'labs':
          old?.data['labs'] ??
          s.courseOfferings(course.id).firstOrNull?.toJson()['labs'] ??
          <AcademicJson>[],
    };
    return s.replaceCollection('offerings', upsert(s, 'offerings', v));
  });

  /// Giữ override và người cũ khi hạ giới hạn; khóa chuyển đợt nếu đã có nhóm.
  Future<void> saveClass(AcademicJson input) => mutate((s) {
    final old = s.classRoom(input['id'] as String? ?? '');
    if (old != null) activeClass(s, old.id);
    final invalid = AcademicPolicy.validateClass(input, s, old);
    if (invalid != null) throw AcademicFailure(invalid);
    final off = s.offering(input['offeringId'] as String)!;
    final code = input['code'].toString().trim().toUpperCase();
    final v = {
      ...?old?.toJson(),
      ...input,
      'id': old?.id ?? nextId('class'),
      'code': code,
      'courseId': off.courseId,
      'semesterId': off.semesterId,
      if (old == null) ...{
        'state': 'active',
        'joinCode': '$code-${nextId('join').split('-').last}',
        'requireApproval': false,
        'qrExpiresAt': '${input['endDate']}T23:59',
        'lecturer': (s.data['currentUser'] as AcademicJson)['name'],
        'groupCount': 0,
        'studentCount': 0,
        'projectCount': 0,
        'pendingReviews': 0,
      },
    };
    return s.replaceCollection('classes', upsert(s, 'classes', v));
  });

  /// Tạo phiên bản rule mới; reviewState, phiên bản và kết quả lịch sử không bị sửa.
  Future<void> saveRule(AcademicJson input) => mutate((s) {
    final error = AcademicPolicy.validateRule(input);
    if (error != null) throw AcademicFailure(error);
    final old = s.rule(input['id'] as String);
    if (old != null && old.version != input['version']) {
      throw const AcademicFailure(
        'Bộ quy tắc đã thay đổi. Mở lại cấu hình trước khi lưu.',
      );
    }
    return s.replaceCollection(
      'ruleSets',
      upsert(s, 'ruleSets', {
        ...input,
        'version': old == null ? 1 : old.version + 1,
      }),
    );
  });

  /// Chỉ gán trong Course đang mở; ghi mục cấp lớp phải clone cấu trúc kế thừa.
  Future<void> assignRule({
    required String courseId,
    required String ruleId,
    required String offeringId,
    String classId = '',
    String itemId = '',
  }) => mutate((s) {
    final off = s.offering(offeringId);
    if (off == null ||
        off.courseId != courseId ||
        s.rule(ruleId)?.active != true) {
      throw const AcademicFailure('Phạm vi hoặc bộ quy tắc không hợp lệ.');
    }
    final cls = classId.isEmpty ? null : activeClass(s, classId);
    if (cls != null &&
        (cls.courseId != courseId ||
            (cls.offeringId != off.id &&
                !(cls.offeringId.isEmpty &&
                    cls.semesterId == off.semesterId)))) {
      throw const AcademicFailure('Lớp không thuộc đợt học đã chọn.');
    }
    final labs = cls == null ? off.labs : s.effectiveLabs(cls);
    if (itemId.isNotEmpty &&
        !labs.expand((l) => l.items).any((i) => i.id == itemId)) {
      throw const AcademicFailure('Mục tài liệu không thuộc phạm vi đã chọn.');
    }
    final changed = [
      for (final l in labs)
        {
          ...l.toJson(),
          'items': [
            for (final i in l.items)
              {...i.toJson(), if (i.id == itemId) 'ruleSetId': ruleId},
          ],
        },
    ];
    final key = cls == null ? 'offerings' : 'classes';
    final v = {
      ...(cls?.toJson() ?? off.toJson()),
      if (itemId.isNotEmpty)
        (cls == null ? 'labs' : 'labOverride'): changed
      else
        (cls == null ? 'ruleSetId' : 'ruleSetOverride'): ruleId,
    };
    return s.replaceCollection(key, upsert(s, key, v));
  });
  Future<void> setClassState(String id, String status) => mutate((s) {
    final cls = s.classRoom(id);
    if (cls == null || !['active', 'archived'].contains(status)) {
      throw const AcademicFailure(
        'Không tìm thấy lớp hoặc trạng thái không hợp lệ.',
      );
    }
    return s.replaceCollection(
      'classes',
      upsert(s, 'classes', {...cls.toJson(), 'state': status}),
    );
  });

  /// Không xóa lớp có người/nhóm/dự án/lịch sử; lưu trữ thay vì mất liên kết.
  Future<void> deleteClass(String id) => mutate((s) {
    final cls = s.classRoom(id);
    if (cls == null) throw const AcademicFailure('Không tìm thấy lớp.');
    if (cls.studentCount > 0 ||
        cls.projectCount > 0 ||
        s.classStudents(id).isNotEmpty ||
        s.classGroups(id).isNotEmpty ||
        ((s.data['reviewState'] as AcademicJson)['requests'] as List).any(
          (r) => r['classCode'] == cls.code || r['classId'] == cls.id,
        )) {
      throw const AcademicFailure(
        'Lớp có dữ liệu. Hãy lưu trữ để giữ lịch sử.',
      );
    }
    return s.replaceCollection('classes', [
      for (final c in s.classes)
        if (c.id != id) c.toJson(),
    ]);
  });
  Future<void> createGroup(String classId, String name) => mutate((s) {
    final cls = activeClass(s, classId);
    final n = name.trim();
    if (n.isEmpty ||
        s
            .classGroups(classId)
            .any((g) => g.name.trim().toLowerCase() == n.toLowerCase())) {
      throw const AcademicFailure(
        'Tên nhóm đã tồn tại trong lớp hoặc đang trống.',
      );
    }
    final next = s.replaceCollection('groups', [
      ...s.values('groups').cast<AcademicJson>(),
      {
        'id': nextId('group'),
        'classId': classId,
        'name': n,
        'health': 'notSubmitted',
        'memberIds': <String>[],
        'progress': 0,
        'pendingReviews': 0,
        'lastActivity': 'Vừa tạo',
      },
    ]);
    return next.replaceCollection(
      'classes',
      upsert(next, 'classes', {
        ...cls.toJson(),
        'groupCount': s.classGroups(classId).length + 1,
      }),
    );
  });
  Future<void> addGroupMember(String groupId, String studentId) => mutate((s) {
    final group = s.groups.where((g) => g.id == groupId).firstOrNull;
    if (group == null) throw const AcademicFailure('Không tìm thấy nhóm.');
    AcademicPolicy.checkMember(s, group, studentId);
    activeClass(s, group.classId);
    return syncGroupMembers(s, group, [...group.memberIds, studentId]);
  });

  /// Lọc trùng trong batch/lớp; lỗi định dạng hoặc vượt sĩ số không ghi dở dang.
  Future<void> enrollStudents(String classId, List<AcademicJson> rows) =>
      mutate((s) {
        final cls = activeClass(s, classId);
        final existing = s.classStudents(classId);
        final codes = existing.map((v) => v.studentCode).toSet();
        final added = <AcademicJson>[];
        for (final r in rows) {
          final code = r['studentCode'].toString().trim().toUpperCase();
          if (!RegExp(r'^[A-Z]{2}\d{6}$').hasMatch(code) ||
              r['name'].toString().trim().isEmpty ||
              !r['email'].toString().contains('@')) {
            throw const AcademicFailure('Thông tin sinh viên không hợp lệ.');
          }
          if (codes.add(code)) {
            added.add({
              ...r,
              'id': nextId('student'),
              'studentCode': code,
              'classId': classId,
              'initials': r['name']
                  .toString()
                  .split(' ')
                  .where((p) => p.isNotEmpty)
                  .take(2)
                  .map((p) => p[0])
                  .join(),
            });
          }
        }
        if (existing.length + added.length > cls.capacity) {
          throw const AcademicFailure(
            'Số sinh viên vượt sĩ số tối đa của lớp.',
          );
        }
        final next = s.replaceCollection('students', [
          ...s.values('students').cast<AcademicJson>(),
          ...added,
        ]);
        return next.replaceCollection(
          'classes',
          upsert(next, 'classes', {
            ...cls.toJson(),
            'studentCount': existing.length + added.length,
          }),
        );
      });
  Future<void> regenerateQr(String classId) => mutate((s) {
    final cls = activeClass(s, classId);
    final suffix = DateTime.now().microsecondsSinceEpoch
        .toRadixString(36)
        .toUpperCase()
        .substring(4, 8);
    return s.replaceCollection(
      'classes',
      upsert(s, 'classes', {
        ...cls.toJson(),
        'joinCode': cls
            .text('joinCode')
            .replaceFirst(RegExp(r'[^-]+$'), suffix),
        'qrExpiresAt': '2026-11-30T23:59',
      }),
    );
  });

  /// Thay cấu trúc đúng một phạm vi, không lan sửa đổi sang lớp đang có override.
  Future<void> saveLabs(
    String offeringId,
    List<AcademicJson> labs, {
    String classId = '',
  }) => mutate((s) {
    final off = s.offering(offeringId);
    if (off == null) throw const AcademicFailure('Không tìm thấy đợt môn học.');
    final cls = classId.isEmpty ? null : activeClass(s, classId);
    if (cls != null && cls.offeringId != off.id) {
      throw const AcademicFailure('Lớp không thuộc đợt môn học.');
    }
    final key = cls == null ? 'offerings' : 'classes';
    return s.replaceCollection(
      key,
      upsert(s, key, {
        ...(cls?.toJson() ?? off.toJson()),
        (cls == null ? 'labs' : 'labOverride'): labs,
      }),
    );
  });
  Future<void> saveTemplate(AcademicLab lab, String scope) => mutate(
    (s) => s.replaceCollection('labTemplates', [
      ...s.values('labTemplates').cast<AcademicJson>(),
      {
        'id': nextId('template'),
        'name': lab.title,
        'lab': AcademicPolicy.cloneLabs([lab], nextId).single,
        'savedFrom': scope,
      },
    ]),
  );

  /// Thao tác cấu trúc Lab là một lần ghi; xóa mục đồng thời gỡ cạnh phụ thuộc.
  Future<void> editLabStructure(
    String offeringId,
    String action, {
    String labId = '',
    String itemId = '',
    String templateId = '',
  }) => mutate((s) {
    final off = s.offering(offeringId);
    if (off == null) throw const AcademicFailure('Không tìm thấy đợt môn học.');
    final labs = off.labs.map((l) => l.toJson()).toList();
    final li = labs.indexWhere((l) => l['id'] == labId);
    void move(List<dynamic> list, int index, int delta) {
      final target = index + delta;
      if (index >= 0 && target >= 0 && target < list.length) {
        final old = list[index];
        list[index] = list[target];
        list[target] = old;
      }
    }

    if (action == 'template') {
      final t = s
          .records('labTemplates')
          .where((t) => t.id == templateId)
          .firstOrNull;
      if (t == null) throw const AcademicFailure('Không tìm thấy mẫu Lab.');
      labs.add({
        ...AcademicPolicy.cloneLabs([
          AcademicLab(t.data['lab'] as AcademicJson),
        ], nextId).single,
        'code': _nextLabCode(off.labs),
      });
    } else {
      if (li < 0) throw const AcademicFailure('Không tìm thấy Lab.');
      final items = (labs[li]['items'] as List).cast<AcademicJson>();
      final ii = items.indexWhere((i) => i['id'] == itemId);
      if (action == 'clone') {
        labs.insert(li + 1, {
          ...AcademicPolicy.cloneLabs([off.labs[li]], nextId).single,
          'code': _nextLabCode(off.labs),
        });
      }
      if (action == 'up' || action == 'down') {
        final delta = action == 'up' ? -1 : 1;
        itemId.isEmpty ? move(labs, li, delta) : move(items, ii, delta);
      }
      if (action == 'delete') {
        final ids = itemId.isEmpty
            ? items.map((i) => i['id']).toSet()
            : {itemId};
        if (itemId.isEmpty) {
          labs.removeAt(li);
        } else {
          items.removeWhere((i) => i['id'] == itemId);
        }
        for (final l in labs) {
          for (final i in l['items'] as List) {
            i['dependsOn'] = (i['dependsOn'] as List? ?? [])
                .where((d) => !ids.contains(d))
                .toList();
          }
        }
      }
    }
    return s.replaceCollection(
      'offerings',
      upsert(s, 'offerings', {...off.toJson(), 'labs': labs}),
    );
  });
  String _nextLabCode(List<AcademicLab> labs) {
    final nums = labs
        .map(
          (l) => int.tryParse(
            RegExp(r'(\d+)\s*$').firstMatch(l.code)?.group(1) ?? '',
          ),
        )
        .whereType<int>();
    return 'Lab ${nums.isEmpty ? labs.length + 1 : nums.reduce((a, b) => a > b ? a : b) + 1}';
  }
}
