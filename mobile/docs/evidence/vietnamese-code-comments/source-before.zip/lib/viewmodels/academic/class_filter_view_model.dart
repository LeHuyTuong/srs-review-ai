import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/academic/academic_models.dart';
import 'academic_view_model.dart';
import '../../app/session.dart';

/// Bộ lọc bất biến; danh sách Course phụ thuộc học kỳ, không phụ thuộc từ khóa.
class ClassFilterState {
  const ClassFilterState({this.q = '', this.facets = const {}});
  final String q;
  final Map<String, List<String>> facets;
  List<String> values(String key) => facets[key] ?? [];
}

final classFilterProvider =
    NotifierProvider<ClassFilterViewModel, ClassFilterState>(
      ClassFilterViewModel.new,
    );

/// Giữ filter và chế độ xem trong phiên fake; không ghi vào nguồn React.
class ClassFilterViewModel extends Notifier<ClassFilterState> {
  final Map<String, ClassFilterState> saved = {};
  @override
  ClassFilterState build() {
    ref.watch(sessionScopeProvider);
    saved.clear();
    return ClassFilterState(
      facets: {
        'semester': [
          ref.read(academicViewModelProvider).requireValue.currentSemesterId,
        ],
        'status': ['active'],
      },
    );
  }

  void query(String q) => state = ClassFilterState(q: q, facets: state.facets);
  void apply(ClassFilterState value) => state = value;
  void clear() => state = const ClassFilterState();
  void set(String key, List<String> values) {
    final f = {...state.facets, key: values};
    if (key == 'semester') f['course'] = [];
    state = ClassFilterState(q: state.q, facets: f);
  }

  void save(String name) {
    saved[name] = state;
    state = ClassFilterState(q: state.q, facets: {...state.facets});
  }

  List<ClassRoom> visible(AcademicSnapshot s) => s.classes.where((c) {
    final fields = {
      'semester': c.semesterId,
      'course': c.courseId,
      'status': c.state,
      'schedule': c.schedule,
      'session': c.session,
    };
    if (fields.entries.any(
      (e) =>
          state.values(e.key).isNotEmpty &&
          !state.values(e.key).contains(e.value),
    )) {
      return false;
    }
    final course = s.course(c.courseId);
    return '${c.code} ${course?.code} ${course?.name}'.toLowerCase().contains(
      state.q.trim().toLowerCase(),
    );
  }).toList();
}
