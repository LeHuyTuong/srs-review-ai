import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/academic/academic_models.dart';
import 'academic_view_model.dart';
import 'review_actions.dart';
import '../../app/session.dart';

/// Trạng thái tương tác AI riêng từng bản nộp, không trộn với kết quả bất biến trong repository.
class ReviewPanelState {
  const ReviewPanelState({
    this.attentionOnly = true,
    this.expanded = const {},
    this.added = const {},
    this.error = '',
  });
  final bool attentionOnly;
  final Set<String> expanded, added;
  final String error;
}

final reviewPanelProvider = NotifierProvider.autoDispose
    .family<ReviewPanelViewModel, ReviewPanelState, String>(
      ReviewPanelViewModel.new,
    );

/// Điều phối tương tác AI và hiển thị lỗi, giữ kết quả/nhật ký ở kho học vụ chung.
class ReviewPanelViewModel extends Notifier<ReviewPanelState> {
  ReviewPanelViewModel(this.id);
  final String id;
  @override
  ReviewPanelState build() {
    ref.watch(sessionScopeProvider);
    return const ReviewPanelState();
  }

  void attention(bool value) => state = ReviewPanelState(
    attentionOnly: value,
    expanded: state.expanded,
    added: state.added,
  );
  void expand(Set<String> values) => state = ReviewPanelState(
    attentionOnly: state.attentionOnly,
    expanded: values,
    added: state.added,
  );
  Future<void> run() async {
    final scope = ref.read(sessionScopeProvider);
    state = ReviewPanelState(
      attentionOnly: state.attentionOnly,
      expanded: state.expanded,
      added: state.added,
    );
    try {
      await ref.read(academicViewModelProvider.notifier).runEvaluation(id);
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: state.added,
        );
      }
    } catch (e) {
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: state.added,
          error: e is AcademicFailure
              ? e.message
              : 'Không thể tạo kết quả. Vui lòng thử lại.',
        );
      }
    }
  }

  Future<void> addFinding(AcademicRecord f) async {
    final scope = ref.read(sessionScopeProvider);
    if (state.added.contains(f.id)) return;
    try {
      await ref.read(academicViewModelProvider.notifier).addFeedback(id, {
        'severity': f.text('level') == 'error' ? 'Major' : 'Minor',
        'category': f.text('category'),
        'pageRef': f.text('pageRef'),
        'message': f.text('message'),
      });
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: {...state.added, f.id},
        );
      }
    } catch (e) {
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: state.added,
          error: e is AcademicFailure ? e.message : 'Không thể thêm phản hồi.',
        );
      }
    }
  }
}
