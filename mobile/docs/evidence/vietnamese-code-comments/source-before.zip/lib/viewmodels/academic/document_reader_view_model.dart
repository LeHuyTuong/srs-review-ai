import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/session.dart';

/// State đọc gắn với review + phiên bản; không ghi vị trí xem vào lịch sử tài liệu.
class DocumentReadingState {
  const DocumentReadingState({this.page = 0, this.offset});
  final int page;
  final double? offset;
}

final documentReaderProvider = NotifierProvider.autoDispose
    .family<DocumentReaderViewModel, DocumentReadingState, String>(
      DocumentReaderViewModel.new,
    );

/// Giữ trang và vị trí toàn màn hình khi đóng/mở lại như readingOffset của React.
class DocumentReaderViewModel extends Notifier<DocumentReadingState> {
  DocumentReaderViewModel(this.key);
  final String key;
  @override
  DocumentReadingState build() {
    ref.watch(sessionScopeProvider);
    return const DocumentReadingState();
  }

  void selectPage(int page, int total) => state = DocumentReadingState(
    page: page.clamp(0, (total - 1).clamp(0, 10000)),
    offset: state.offset,
  );
  void rememberOffset(double value) {
    if (value.isFinite && value >= 0) {
      state = DocumentReadingState(page: state.page, offset: value);
    }
  }
}
