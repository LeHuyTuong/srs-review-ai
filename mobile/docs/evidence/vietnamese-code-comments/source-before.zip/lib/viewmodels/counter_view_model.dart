import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../app/providers.dart';
import '../models/counter_state.dart';

final counterViewModelProvider =
    NotifierProvider<CounterViewModel, CounterState>(CounterViewModel.new);

/// Điều phối counter foundation qua repository, giữ View độc lập bộ nhớ tạm.
class CounterViewModel extends Notifier<CounterState> {
  @override
  CounterState build() => ref.watch(counterRepositoryProvider).load();

  /// Tăng số đếm qua nguồn dữ liệu và thay snapshot state bất biến.
  void increment() {
    state = ref.read(counterRepositoryProvider).increment();
  }
}
