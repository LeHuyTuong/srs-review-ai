import 'dart:convert';

import 'package:flutter/services.dart';

/// Đọc fixture đã trích từ store React; không mô phỏng backend Lab 3 cuối cùng.
class FakeDashboardService {
  const FakeDashboardService(this._bundle, {this.loadData});
  final AssetBundle _bundle;
  final Future<Map<String, dynamic>> Function()? loadData;

  /// Lỗi thiếu asset hoặc JSON không hợp lệ được chuyển lên repository/ViewModel.
  Future<Map<String, dynamic>> load() async => loadData != null
      ? await loadData!()
      : jsonDecode(await _bundle.loadString('assets/fixtures/dashboard.json'))
            as Map<String, dynamic>;
}
