import 'package:file_selector/file_selector.dart';
import 'package:flutter/services.dart';

import '../../repositories/academic/student_device_gateway.dart';

/// Cầu nối thiết bị được DI; Widget không đọc tệp hoặc gọi clipboard trực tiếp.
class StudentImportService implements StudentDeviceGateway {
  @override
  Future<({String name, String? csv})?> pick() async {
    final file = await openFile(
      acceptedTypeGroups: [
        const XTypeGroup(
          label: 'Danh sách sinh viên',
          extensions: ['csv', 'xlsx'],
        ),
      ],
    );
    if (file == null) return null;
    return (
      name: file.name,
      csv: file.name.toLowerCase().endsWith('.csv')
          ? await file.readAsString()
          : null,
    );
  }

  @override
  Future<void> copy(String text) =>
      Clipboard.setData(ClipboardData(text: text));
}
