import 'dart:convert';

import 'package:flutter/services.dart';

import '../../models/academic/academic_models.dart';
import '../../models/session_scope.dart';
import '../../repositories/academic/course_contract.dart';

/// Shared in-memory fake server: committed data outlives client sessions.
class FakeAcademicService {
  FakeAcademicService(this._bundle);
  final AssetBundle _bundle;
  AcademicSnapshot? _snapshot;
  Future<AcademicSnapshot>? _loading;
  Future<AcademicSnapshot> load() =>
      _snapshot != null ? Future.value(_snapshot!) : _loading ??= _read();
  Future<AcademicSnapshot> _read() async {
    try {
      return _snapshot = AcademicSnapshotCodec.decode(
        jsonDecode(await _bundle.loadString('assets/fixtures/academic.json')),
      );
    } finally {
      _loading = null;
    }
  }

  /// So phiên bản trước khi thay snapshot để một form cũ không ghi đè dữ liệu mới.
  Future<AcademicSnapshot> commitCourse(
    CourseMutation command,
    int expectedRevision, {
    SessionScope? scope,
  }) async {
    final current = await load();
    scope?.requireActive();
    return commit(command.apply(current), expectedRevision, scope: scope);
  }

  Future<AcademicSnapshot> commit(
    AcademicSnapshot next,
    int expectedRevision, {
    SessionScope? scope,
  }) async {
    await load();
    scope?.requireActive();
    final current = _snapshot!;
    if (current.revision != expectedRevision) {
      throw const AcademicFailure(
        'Dữ liệu đã thay đổi. Đóng form và mở lại để tiếp tục.',
        code: AcademicErrorCode.conflict,
      );
    }
    final ids = <String>{}, codes = <String>{};
    for (final course in next.courses) {
      CourseDto.fromJson(course.toJson());
      if (course.id.isEmpty || !ids.add(course.id)) {
        throw const AcademicFailure('ID môn học đã tồn tại hoặc không hợp lệ.');
      }
      if (!codes.add(course.code.trim().toUpperCase())) {
        throw const AcademicFailure('Mã môn đã tồn tại.');
      }
    }
    return _snapshot = AcademicSnapshot({
      ...next.toJson(),
      'revision': current.revision + 1,
    });
  }
}
