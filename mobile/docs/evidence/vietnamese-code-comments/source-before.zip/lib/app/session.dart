import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/session_scope.dart';

/// Temporary demo session, replaced by Google Sign-In during Firebase integration.
/// Incoming/restored role values are untrusted; Mobile admits Supervisor only.
class AppSession {
  const AppSession(
    this.role, {
    this.userId = 'mock-supervisor',
    this.generation = 0,
  });
  final String role;
  final String userId;
  final int generation;
  bool get isSupervisor => role == 'supervisor';
}

final initialSessionProvider = Provider<AppSession?>((ref) => null);
final sessionProvider = NotifierProvider<SessionViewModel, AppSession?>(
  SessionViewModel.new,
);

final sessionScopeProvider = Provider<SessionScope>((ref) {
  ref.watch(sessionProvider);
  final scope = ref.read(sessionProvider.notifier).scope;
  ref.onDispose(scope.close);
  return scope;
});

class SessionViewModel extends Notifier<AppSession?> {
  SessionScope scope = SessionScope(null);
  int _generation = 0;
  @override
  AppSession? build() {
    final initial = ref.read(initialSessionProvider);
    final valid = initial?.isSupervisor == true ? initial : null;
    scope = SessionScope(valid?.userId);
    ref.onDispose(() => scope.close());
    return valid;
  }

  void signIn(String role, String email, String password) {
    if (role != 'supervisor') {
      throw const FormatException('Ứng dụng Mobile chỉ dành cho giảng viên.');
    }
    if (email.trim().isEmpty || password.isEmpty) {
      throw const FormatException('Vui lòng nhập email và mật khẩu.');
    }
    scope.close();
    scope = SessionScope('mock:${email.trim().toLowerCase()}');
    state = AppSession(
      'supervisor',
      userId: 'mock:${email.trim().toLowerCase()}',
      generation: ++_generation,
    );
  }

  void signOut() {
    // Revoke synchronously; pending work must fail even before the next frame.
    if (state == null) return;
    scope.close();
    scope = SessionScope(null);
    state = null;
  }
}
