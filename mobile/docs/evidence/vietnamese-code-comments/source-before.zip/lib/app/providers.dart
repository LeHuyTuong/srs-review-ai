import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart';

import '../services/dashboard/fake_dashboard_service.dart';
import '../repositories/dashboard/dashboard_repository.dart';
import '../repositories/dashboard/fake_dashboard_repository.dart';

import '../repositories/counter_repository.dart';
import '../services/demo_counter_service.dart';
import '../services/academic/fake_academic_service.dart';
import '../repositories/academic/academic_repository.dart';
import '../repositories/academic/fake_academic_repository.dart';
import '../repositories/academic/student_device_gateway.dart';
import '../services/academic/student_import_service.dart';
import 'session.dart';

// Điểm ghép phụ thuộc: View/ViewModel không tự tạo nguồn dữ liệu cụ thể.
final demoCounterServiceProvider = Provider<DemoCounterService>(
  (ref) => DemoCounterService(),
);

final counterRepositoryProvider = Provider<CounterRepository>(
  (ref) => DemoCounterRepository(ref.watch(demoCounterServiceProvider)),
);

final dashboardServiceProvider = Provider<FakeDashboardService>((ref) {
  final repository = ref.watch(academicRepositoryProvider);
  return FakeDashboardService(
    rootBundle,
    loadData: () async => (await repository.load()).dashboardJson,
  );
});

final dashboardRepositoryProvider = Provider<DashboardRepository>(
  (ref) => FakeDashboardRepository(ref.watch(dashboardServiceProvider)),
);

// Shared fake server store. Only committed domain data survives a session.
final academicServiceProvider = Provider<FakeAcademicService>(
  (ref) => FakeAcademicService(rootBundle),
);
final studentImportServiceProvider = Provider<StudentDeviceGateway>(
  (ref) => StudentImportService(),
);
final academicRepositoryProvider = Provider<AcademicRepository>(
  (ref) => FakeAcademicRepository(
    ref.watch(academicServiceProvider),
    scope: ref.watch(sessionScopeProvider),
  ),
);
