import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import '../screens/dashboard/dashboard_screen.dart';
import '../screens/navigation_destination_screen.dart';
import '../screens/academic/course_screens.dart';
import '../screens/academic/offering_detail_screen.dart';
import '../screens/academic/class_screens.dart';
import '../theme/app_theme.dart';
import '../screens/management/group_screens.dart';
import '../screens/management/project_screens.dart';
import '../screens/management/document_screens.dart';
import '../screens/management/review_screens.dart';
import '../screens/management/review_history_screens.dart';
import 'session.dart';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../screens/account/login_screen.dart';
import '../screens/account/account_screens.dart';
import '../screens/academic/directory_screens.dart';

/// Điểm vào Supervisor; router native nối Dashboard và các màn học vụ đã chuyển.
class SrsReviewApp extends ConsumerWidget {
  const SrsReviewApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) => MaterialApp(
    key: ValueKey(ref.watch(sessionProvider)),
    title: 'SRS Đánh giá AI',
    debugShowCheckedModeBanner: false,
    theme: AppTheme.light,
    locale: const Locale('vi'),
    supportedLocales: const [Locale('vi')],
    localizationsDelegates: GlobalMaterialLocalizations.delegates,
    home: const DashboardScreen(),
    builder: (context, child) {
      final session = ref.watch(sessionProvider);
      if (session?.isSupervisor != true) {
        return Navigator(
          key: const ValueKey('signed-out'),
          onGenerateRoute: (_) =>
              MaterialPageRoute<void>(builder: (_) => const LoginScreen()),
        );
      }
      return child!;
    },
    onGenerateRoute: (settings) => MaterialPageRoute<void>(
      settings: settings,
      builder: (_) {
        final path = settings.name ?? '/dashboard';
        final parts = Uri.parse(path).pathSegments;
        return switch (parts) {
          [] || ['dashboard'] || ['login'] => const DashboardScreen(),
          ['profile'] => const ProfileScreen(),
          ['notifications'] => const NotificationsScreen(),
          ['semesters'] => const SemesterListScreen(),
          ['students'] => const StudentDirectoryScreen(),
          ['courses'] => const CourseListScreen(),
          ['courses', final id] => CourseDetailScreen(courseId: id),
          ['course-offerings', final id] => OfferingDetailScreen(
            offeringId: id,
          ),
          ['classes'] => const ClassListScreen(),
          ['classes', final id] => ClassDetailScreen(classId: id),
          ['rule-sets'] => const RuleSetSelectionScreen(),
          ['groups'] => const GroupListScreen(),
          ['groups', final id] => GroupDetailScreen(groupId: id),
          ['projects'] => const ProjectListScreen(),
          ['projects', final id] => ProjectDetailScreen(projectId: id),
          ['projects', final id, 'documents'] => ProjectDocumentsScreen(
            projectId: id,
          ),
          ['project-registrations'] => const ProjectRegistrationsScreen(),
          ['documents'] => const DocumentListScreen(),
          ['reviews'] => const ReviewListScreen(),
          ['reviews', final id] => ReviewWorkspaceScreen(reviewId: id),
          ['reviews', final id, 'ai-result'] => AiResultScreen(reviewId: id),
          ['reviews', final id, 'versions'] => VersionHistoryScreen(
            reviewId: id,
          ),
          ['reviews', final id, 'history'] => ReviewHistoryScreen(reviewId: id),
          ['review-history'] => const ReviewHistoryIndexScreen(),
          _ => NavigationDestinationScreen(path: path),
        };
      },
    ),
  );
}
