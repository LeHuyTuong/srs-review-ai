import 'package:flutter/material.dart';

/// Giới hạn chuyển trang tại app; Tổng quan được giữ trong stack để khôi phục bộ lọc.
abstract final class AppNavigation {
  static void open(BuildContext context, String path) {
    if (path == '/dashboard') {
      Navigator.of(context).popUntil((route) => route.isFirst);
    } else if (ModalRoute.of(context)?.settings.name != path) {
      Navigator.of(context).pushNamed(path);
    }
  }
}
