import 'package:flutter/material.dart';

import 'app_colors.dart';

/// Độ nổi từ handoff; chỉ áp dụng cho component nguồn thực sự có bóng.
abstract final class AppShadows {
  static final elevation1 = [
    BoxShadow(
      color: AppColors.ink.withValues(alpha: 0.06),
      offset: const Offset(0, 1),
      blurRadius: 2,
    ),
  ];
  static final elevation2 = [
    BoxShadow(
      color: AppColors.ink.withValues(alpha: 0.08),
      offset: const Offset(0, 2),
      blurRadius: 8,
    ),
  ];
  static final elevation3 = [
    BoxShadow(
      color: AppColors.ink.withValues(alpha: 0.12),
      offset: const Offset(0, 8),
      blurRadius: 24,
    ),
  ];
}
