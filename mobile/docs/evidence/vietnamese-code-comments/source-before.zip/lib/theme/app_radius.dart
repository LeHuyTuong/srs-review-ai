/// Bo góc từ handoff và CSS thực tế; giữ riêng giá trị modal đang dùng.
abstract final class AppRadius {
  static const chip = 6.0;
  static const button = 8.0;
  static const card = 12.0;
  static const dialog = 16.0; // Giá trị handoff Lab 2.
  static const modal = 12.0; // Giá trị thực tế trong Modal.tsx.
  static const pill = 999.0;
}
