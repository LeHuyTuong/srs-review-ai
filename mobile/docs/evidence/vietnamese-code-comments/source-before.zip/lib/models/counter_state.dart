/// State bất biến của demo foundation, không đại diện dữ liệu nghiệp vụ SRS.
class CounterState {
  const CounterState({this.count = 0});

  final int count;
}
