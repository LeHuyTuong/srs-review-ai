import 'academic/academic_models.dart';

/// A revocable client-operation lifetime, distinct from durable shared data.
class SessionScope {
  SessionScope(this.userId);
  final String? userId;
  bool _active = true;
  bool get active => _active;
  void close() => _active = false;
  void requireActive() {
    if (!_active) {
      throw const AcademicFailure(
        'Phiên đã kết thúc. Vui lòng đăng nhập lại.',
        code: AcademicErrorCode.sessionExpired,
      );
    }
  }
}
