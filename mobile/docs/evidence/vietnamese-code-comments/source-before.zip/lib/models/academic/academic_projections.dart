import 'academic_models.dart';

/// Pure business projections shared by ViewModels; no UI dependencies.
abstract final class AcademicProjections {
  static List<AcademicSemester> semesters(AcademicSnapshot snapshot) {
    const rank = {
      'Đang diễn ra': 0,
      'Sắp diễn ra': 1,
      'Đã kết thúc': 2,
      'Lưu trữ': 3,
    };
    final result = [...snapshot.semesters]
      ..sort((a, b) {
        final n = rank[semesterPhase(a, snapshot.integer('now'))]!.compareTo(
          rank[semesterPhase(b, snapshot.integer('now'))]!,
        );
        return n != 0 ? n : b.startDate.compareTo(a.startDate);
      });
    return List.unmodifiable(result);
  }

  static String semesterPhase(AcademicSemester semester, int now) {
    if (semester.archived) return 'Lưu trữ';
    final current = DateTime.fromMillisecondsSinceEpoch(now);
    final start = DateTime.parse(semester.startDate);
    final end = DateTime.parse(semester.endDate).add(const Duration(days: 1));
    if (current.isBefore(start)) return 'Sắp diễn ra';
    return current.isBefore(end) ? 'Đang diễn ra' : 'Đã kết thúc';
  }

  static int groupedStudents(
    Iterable<AcademicStudent> students,
    Iterable<StudentGroup> groups,
  ) {
    final members = groups.expand((g) => g.memberIds).toSet();
    return students.where((student) => members.contains(student.id)).length;
  }

  static num criterionTotal(Iterable<dynamic> criteria) => criteria
      .where((c) => c['enabled'] == true)
      .fold<num>(
        0,
        (sum, c) => sum + (c['maxScore'] is num ? c['maxScore'] as num : 0),
      );
}

class ProjectDocumentProjection {
  ProjectDocumentProjection(List<AcademicRecord> documents, int tab)
    : counts = List.unmodifiable(
        List.generate(4, (i) => documents.where((d) => matches(d, i)).length),
      ),
      visible = List.unmodifiable(
        documents.where((d) => matches(d, tab)).toList()..sort((a, b) {
          final difference = priority(a).compareTo(priority(b));
          return difference != 0
              ? difference
              : a.integer('order').compareTo(b.integer('order'));
        }),
      );
  final List<int> counts;
  final List<AcademicRecord> visible;
  static bool matches(AcademicRecord document, int tab) => switch (tab) {
    1 => ['waiting', 'inReview'].contains(document.text('supervisorStatus')),
    2 => document.text('supervisorStatus') == 'needsRevision',
    3 => document.flag('submissionLocked'),
    _ => true,
  };
  static int priority(AcademicRecord document) =>
      const {'inReview': 0, 'waiting': 1, 'needsRevision': 2}[document.text(
        'supervisorStatus',
      )] ??
      3;
}
