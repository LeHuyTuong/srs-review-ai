import 'academic_models.dart';

/// Kiểm tra thuần Dart dùng chung ở form và lệnh ghi, bám validateRule của React.
abstract final class AcademicPolicy {
  static String? validateRule(AcademicJson r) {
    bool finite(String k) => r[k] is num && (r[k] as num).isFinite;
    if ((r['id']?.toString().trim() ?? '').isEmpty ||
        (r['name']?.toString().trim() ?? '').isEmpty) {
      return 'Cần ID và tên bộ quy tắc.';
    }
    if ((r['allowedFormats'] as List? ?? []).isEmpty ||
        !finite('maxFileSizeMB') ||
        (r['maxFileSizeMB'] as num) <= 0 ||
        !finite('reviewSlaDays') ||
        (r['reviewSlaDays'] as num) <= 0) {
      return 'Định dạng, dung lượng và hạn đánh giá phải hợp lệ.';
    }
    final max = r['maxResubmissions'];
    if (max != null &&
        (max is! num || !max.isFinite || max < 0 || max % 1 != 0)) {
      return 'Số lần nộp lại phải là số nguyên không âm.';
    }
    if (r['aiRequiredBeforeSupervisor'] == true && r['aiEnabled'] != true) {
      return 'Không thể bắt buộc AI khi AI bị tắt.';
    }
    if (!finite('passThreshold') ||
        !finite('improveThreshold') ||
        (r['passThreshold'] as num) > 100 ||
        (r['improveThreshold'] as num) < 0 ||
        (r['passThreshold'] as num) <= (r['improveThreshold'] as num)) {
      return 'Ngưỡng cần cải thiện phải thấp hơn ngưỡng đạt (0–100%).';
    }
    final cs = (r['criteria'] as List? ?? []).cast<AcademicJson>();
    if (cs.map((c) => c['id']).toSet().length != cs.length ||
        cs.any(
          (c) =>
              (c['id']?.toString().trim() ?? '').isEmpty ||
              (c['name']?.toString().trim() ?? '').isEmpty ||
              c['maxScore'] is! num ||
              !(c['maxScore'] as num).isFinite ||
              (c['maxScore'] as num) <= 0,
        )) {
      return 'Tiêu chí cần ID duy nhất, tên và điểm tối đa lớn hơn 0.';
    }
    if (r['status'] == 'active' &&
        (!cs.any((c) => c['enabled'] == true) ||
            r['templateMissing'] == true)) {
      return 'Cần ít nhất một tiêu chí bật và checklist đầy đủ trước khi kích hoạt.';
    }
    if (r['status'] == 'active' &&
        r['aiRequiredBeforeSupervisor'] == true &&
        !cs.any((c) => c['enabled'] == true && c['aiEnabled'] == true)) {
      return 'Cần ít nhất một tiêu chí bật AI để bắt buộc Đánh giá AI.';
    }
    return null;
  }

  static AcademicJson newRule(String id) => {
    'id': id,
    'name': '',
    'description': '',
    'version': 1,
    'status': 'draft',
    'aiEnabled': true,
    'aiReview': 'manual',
    'aiRequiredBeforeSupervisor': false,
    'supervisorApproval': true,
    'prerequisiteApproval': true,
    'resubmissionEnabled': true,
    'allowedFormats': ['PDF', 'DOCX'],
    'maxFileSizeMB': 20,
    'reviewSlaDays': 3,
    'documentType': 'Tất cả',
    'criteria': <AcademicJson>[],
    'passThreshold': 80,
    'improveThreshold': 70,
    'scoringMode': 'weighted',
  };
  static AcademicJson newCriterion(String id) => {
    'id': id,
    'name': '',
    'description': '',
    'maxScore': 10,
    'enabled': true,
    'required': false,
    'critical': false,
    'evidenceRequired': true,
    'aiEnabled': true,
    'instruction': '',
    'evidenceRequirement': '',
    'suggestScore': true,
    'suggestFindings': true,
    'suggestSuggestions': true,
  };

  static String? validateClass(
    AcademicJson v,
    AcademicSnapshot s,
    ClassRoom? old,
  ) {
    if ((v['code']?.toString().trim() ?? '').isEmpty) return 'Nhập mã lớp.';
    final off = s.offering(v['offeringId'] as String? ?? '');
    if (off == null) return 'Chọn môn học trong học kỳ.';
    final start = DateTime.tryParse(v['startDate']?.toString() ?? '');
    final end = DateTime.tryParse(v['endDate']?.toString() ?? '');
    if (start == null || end == null || !end.isAfter(start)) {
      return 'Ngày kết thúc phải sau ngày bắt đầu.';
    }
    for (final key in ['capacity', 'maxGroupMembers']) {
      final n = v[key];
      if (n is! num || !n.isFinite || n <= 0 || n % 1 != 0) {
        return key == 'capacity'
            ? 'Sĩ số tối đa phải là số nguyên dương.'
            : 'Số thành viên tối đa mỗi nhóm phải là số nguyên dương.';
      }
    }
    if (old != null &&
        (old.groupCount > 0 || s.classGroups(old.id).isNotEmpty) &&
        off.id != old.offeringId) {
      return 'Lớp đã có nhóm nên không thể chuyển sang môn học khác.';
    }
    if (s.classes.any(
      (c) =>
          c.id != old?.id &&
          c.code.toUpperCase() == v['code'].toString().trim().toUpperCase(),
    )) {
      return 'Mã lớp đã tồn tại.';
    }
    return null;
  }

  /// Hạ giới hạn không xóa người cũ; khi thêm phải còn chỗ và thuộc đúng lớp.
  static void checkMember(
    AcademicSnapshot s,
    StudentGroup group,
    String studentId,
  ) {
    final cls = s.classRoom(group.classId);
    if (cls == null || cls.archived) {
      throw const AcademicFailure('Lớp đã lưu trữ hoặc không còn tồn tại.');
    }
    final student = s.students.where((v) => v.id == studentId).firstOrNull;
    if (student == null || !student.belongsTo(cls.id)) {
      throw const AcademicFailure('Sinh viên phải thuộc đúng lớp của nhóm.');
    }
    if (s.classGroups(cls.id).any((g) => g.memberIds.contains(studentId))) {
      throw const AcademicFailure('Sinh viên đã có nhóm trong lớp.');
    }
    if (group.memberIds.length >= cls.memberLimit) {
      throw const AcademicFailure('Nhóm đã đạt giới hạn thành viên của lớp.');
    }
  }

  /// Bản sao đổi ID cả Lab/mục, ánh xạ phụ thuộc và không chia sẻ cấu trúc ghi.
  static List<AcademicJson> cloneLabs(
    List<AcademicLab> labs,
    String Function(String) id,
  ) {
    final ids = {for (final i in labs.expand((l) => l.items)) i.id: id('item')};
    return [
      for (final l in labs)
        {
          ...l.toJson(),
          'id': id('lab'),
          'items': [
            for (final i in l.items)
              {
                ...i.toJson(),
                'id': ids[i.id],
                'dependsOn': i.dependencies.map((d) => ids[d] ?? d).toList(),
              },
          ],
        },
    ];
  }
}
