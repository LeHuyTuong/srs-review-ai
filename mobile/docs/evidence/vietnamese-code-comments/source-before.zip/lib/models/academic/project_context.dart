/// A linked group's class is authoritative; detached projects retain classId.
String resolveProjectClassId(String? groupClassId, String directClassId) =>
    groupClassId?.isNotEmpty == true ? groupClassId! : directClassId;
