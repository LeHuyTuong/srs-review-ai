import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../models/academic/academic_models.dart';
import '../../../viewmodels/academic/class_filter_view_model.dart';
import '../../../viewmodels/academic/academic_form_view_model.dart';
import '../../../widgets/app_academic_layout.dart';
import '../../../widgets/app_button.dart';
import '../../../theme/app_spacing.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_typography.dart';
import '../../../widgets/app_icon.dart';
import '../../../widgets/app_filter_controls.dart';
import 'academic_form_sheet.dart';
import '../../../widgets/app_search_field.dart';

/// Thanh lọc mobile giữ chip học kỳ/trạng thái và drawer áp dụng một lần.
class ClassFilterBar extends ConsumerWidget {
  const ClassFilterBar({required this.snapshot, super.key});
  final AcademicSnapshot snapshot;
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final filter = ref.watch(classFilterProvider);
    final vm = ref.read(classFilterProvider.notifier);
    final count = filter.facets.entries
        .where((e) => e.key != 'semester')
        .fold<int>(0, (n, e) => n + e.value.length);
    const titles = {
      'semester': 'Học kỳ',
      'course': 'Môn học',
      'status': 'Trạng thái lớp',
      'schedule': 'Lịch học',
      'session': 'Buổi',
    };
    final labels = {
      for (final s in snapshot.semesters) s.id: s.name,
      for (final c in snapshot.courses) c.id: c.code,
      'active': 'Đang giảng dạy',
      'archived': 'Đã lưu trữ',
      '25': 'T2 – T5',
      '36': 'T3 – T6',
      '47': 'T4 – T7',
      'morning': 'Sáng',
      'afternoon': 'Chiều',
      'evening': 'Tối',
    };
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      spacing: AppSpacing.m,
      children: [
        Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          spacing: AppSpacing.s,
          children: [
            AppSearchField(
              value: filter.q,
              style: AppTypography.body,
              decoration: const InputDecoration(
                filled: true,
                fillColor: AppColors.subtle,
                hintText: 'Tìm lớp...',
                prefixIcon: Padding(
                  padding: EdgeInsets.all(AppSpacing.m),
                  child: AppIcon('search'),
                ),
              ),
              onChanged: vm.query,
            ),
            Row(
              spacing: AppSpacing.s,
              children: [
                AppSelectButton(
                  label: filter.values('semester').isEmpty
                      ? 'Học kỳ'
                      : snapshot
                                .semester(filter.values('semester').first)
                                ?.name ??
                            'Học kỳ',
                  selected: filter.values('semester').isNotEmpty,
                  options: {
                    '': 'Tất cả học kỳ',
                    for (final s in snapshot.semesters) s.id: s.name,
                  },
                  onChanged: (v) => vm.set('semester', v.isEmpty ? [] : [v]),
                ),
                AppButton(
                  label: count > 0 ? 'Bộ lọc · $count' : 'Bộ lọc',
                  icon: const AppIcon('sliders-horizontal'),
                  selected: count > 0,
                  variant: AppButtonVariant.secondary,
                  onPressed: () => showAppSheet(
                    context,
                    _ClassFilterSheet(
                      snapshot: snapshot,
                      initial: filter,
                      onApply: vm.apply,
                    ),
                  ),
                ),
                const Spacer(),
                AppMoreMenu(
                  label: 'Chế độ xem',
                  actions: {
                    'Lưu chế độ xem': () async {
                      final c = TextEditingController();
                      final name = await showDialog<String>(
                        context: context,
                        builder: (d) => AlertDialog(
                          title: const Text('Lưu chế độ xem'),
                          content: TextField(
                            controller: c,
                            decoration: const InputDecoration(
                              labelText: 'Tên chế độ xem',
                            ),
                          ),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(d),
                              child: const Text('Hủy'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(d, c.text),
                              child: const Text('Lưu'),
                            ),
                          ],
                        ),
                      );
                      c.dispose();
                      if (name?.trim().isNotEmpty == true) {
                        vm.save(name!.trim());
                      }
                    },
                    for (final e in vm.saved.entries)
                      e.key: () => vm.apply(e.value),
                  },
                ),
              ],
            ),
          ],
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            spacing: AppSpacing.s,
            children: [
              for (final e in filter.facets.entries)
                for (final value in e.value)
                  AppFilterChip(
                    label: '${titles[e.key]}: ${labels[value] ?? value}',
                    onRemove: () => vm.set(
                      e.key,
                      e.value.where((v) => v != value).toList(),
                    ),
                  ),
              if (filter.facets.values.any((v) => v.isNotEmpty))
                TextButton(
                  onPressed: vm.clear,
                  child: const Text('Xóa bộ lọc'),
                ),
            ],
          ),
        ),
        Text('${vm.visible(snapshot).length} lớp', style: AppTypography.strong),
      ],
    );
  }
}

class _ClassFilterSheet extends StatefulWidget {
  const _ClassFilterSheet({
    required this.snapshot,
    required this.initial,
    required this.onApply,
  });
  final AcademicSnapshot snapshot;
  final ClassFilterState initial;
  final ValueChanged<ClassFilterState> onApply;
  @override
  State<_ClassFilterSheet> createState() => _ClassFilterSheetState();
}

class _ClassFilterSheetState extends State<_ClassFilterSheet> {
  late Map<String, List<String>> facets = {...widget.initial.facets};
  @override
  Widget build(BuildContext context) {
    final courseIds = widget.snapshot.classes
        .where(
          (c) =>
              (facets['semester'] ?? []).isEmpty ||
              (facets['semester']!).contains(c.semesterId),
        )
        .map((c) => c.courseId)
        .toSet();
    return AppSheetLayout(
      title: 'Bộ lọc lớp',
      footer: Row(
        spacing: AppSpacing.s,
        children: [
          Expanded(
            child: AppButton(
              label: 'Xóa',
              variant: AppButtonVariant.secondary,
              onPressed: () => setState(() => facets = {}),
            ),
          ),
          Expanded(
            child: AppButton(
              label: 'Áp dụng',
              onPressed: () {
                widget.onApply(
                  ClassFilterState(q: widget.initial.q, facets: facets),
                );
                Navigator.pop(context);
              },
            ),
          ),
        ],
      ),
      children: [
        for (final f in [
          AcademicField(
            'course',
            'Môn học',
            type: 'multi',
            options: {
              for (final c in widget.snapshot.courses.where(
                (c) => courseIds.contains(c.id),
              ))
                c.id: c.code,
            },
          ),
          const AcademicField(
            'status',
            'Trạng thái lớp',
            type: 'multi',
            options: {'active': 'Đang giảng dạy', 'archived': 'Đã lưu trữ'},
          ),
          const AcademicField(
            'schedule',
            'Lịch học',
            type: 'multi',
            options: {'25': 'T2 – T5', '36': 'T3 – T6', '47': 'T4 – T7'},
          ),
          const AcademicField(
            'session',
            'Buổi',
            type: 'multi',
            options: {
              'morning': 'Sáng',
              'afternoon': 'Chiều',
              'evening': 'Tối',
            },
          ),
        ])
          AcademicFieldView(
            field: f,
            value: facets[f.key] ?? [],
            onChanged: (v) => setState(
              () => facets = {...facets, f.key: List<String>.from(v as List)},
            ),
          ),
      ],
    );
  }
}
