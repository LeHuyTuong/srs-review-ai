import 'package:flutter/material.dart';

import '../../../app/app_navigation.dart';
import '../../../models/academic/academic_models.dart';
import '../../../theme/app_spacing.dart';
import '../../../theme/app_colors.dart';
import '../../../theme/app_typography.dart';
import '../../../widgets/app_badge.dart';
import '../../../widgets/app_card.dart';
import '../../../widgets/app_button.dart';
import '../../../widgets/app_meta_grid.dart';
import '../../../theme/app_metrics.dart';
import '../../../widgets/app_disclosure.dart';

/// Tóm tắt nhóm của ClassDetail, không triển khai màn hình quản trị dự án ngoài phase.
class GroupSummaryCard extends StatelessWidget {
  const GroupSummaryCard({
    required this.group,
    required this.snapshot,
    this.compact = false,
    super.key,
  });
  final StudentGroup group;
  final AcademicSnapshot snapshot;
  final bool compact;
  @override
  Widget build(BuildContext context) {
    final g = group;
    final p = snapshot
        .records('projects')
        .where((p) => p.id == g.projectId)
        .firstOrNull;
    final limit = snapshot.classRoom(g.classId)!.memberLimit;
    final health =
        (snapshot.data['groupHealthMeta'] as Map)[g.text('health')] as Map?;
    if (compact) {
      return Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppSpacing.l,
          vertical: AppSpacing.m,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          spacing: AppSpacing.xs,
          children: [
            Row(
              spacing: AppSpacing.s,
              children: [
                Expanded(
                  child: TextButton(
                    onPressed: () =>
                        AppNavigation.open(context, '/groups/${g.id}'),
                    style: TextButton.styleFrom(
                      alignment: Alignment.centerLeft,
                      padding: EdgeInsets.zero,
                    ),
                    child: Text(
                      g.name,
                      style: AppTypography.blockTitle.copyWith(
                        color: AppColors.brand,
                      ),
                    ),
                  ),
                ),
                if (p != null)
                  AppBadge(
                    p.text('state') == 'archived'
                        ? 'Đã lưu trữ'
                        : 'Đang thực hiện',
                    tone: p.text('state') == 'archived' ? 'neutral' : 'brand',
                  ),
              ],
            ),
            TextButton(
              onPressed: () => AppNavigation.open(
                context,
                p == null ? '/groups/${g.id}' : '/projects/${p.id}',
              ),
              style: TextButton.styleFrom(padding: EdgeInsets.zero),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      p?.name ?? 'Gán dự án',
                      style: AppTypography.effectiveSmall,
                    ),
                  ),
                  const Text('›'),
                ],
              ),
            ),
            Text(
              '${g.memberIds.length}/$limit thành viên · ${g.integer('pendingReviews')} chờ đánh giá',
              style: AppTypography.muted,
            ),
            if (g.memberIds.length > limit)
              const Text('Vượt giới hạn · Không thể thêm thành viên'),
            AppDisclosure(
              title: 'Thông tin nhóm',
              divider: false,
              muted: true,
              showArrow: false,
              titleWidget: Text(
                'Thông tin nhóm',
                style: AppTypography.effectiveSmall.copyWith(
                  color: AppColors.muted,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                spacing: AppSpacing.m,
                children: [
                  AcademicProgress(
                    value: g.integer('progress'),
                    label: 'Tiến độ nhóm (ghi nhận)',
                  ),
                  if (p?.text('state') != 'archived')
                    Text(health?['label']?.toString() ?? ''),
                  Text(
                    'Hoạt động: ${((snapshot.data['presentation'] as Map)['activities'] as Map)[g.id] ?? g.text('lastActivity')}',
                    style: AppTypography.muted,
                  ),
                  AppButton(
                    label: 'Quản lý nhóm',
                    variant: AppButtonVariant.secondary,
                    onPressed: () =>
                        AppNavigation.open(context, '/groups/${g.id}'),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        spacing: AppSpacing.m,
        children: [
          Wrap(
            alignment: WrapAlignment.spaceBetween,
            spacing: AppSpacing.s,
            runSpacing: AppSpacing.s,
            children: [
              Text(g.name, style: AppTypography.muted),
              if (p != null)
                AppBadge(
                  const {
                        'active': 'Đang thực hiện',
                        'archived': 'Đã lưu trữ',
                        'completed': 'Hoàn thành',
                        'draft': 'Bản nháp',
                      }[p.text('state')] ??
                      p.text('state'),
                  tone: p.text('state') == 'active' ? 'brand' : 'neutral',
                ),
              if (p?.text('state') != 'archived')
                AppBadge(
                  health?['label']?.toString() ?? '',
                  tone: health?['tone']?.toString() ?? 'neutral',
                ),
            ],
          ),
          Text(p?.name ?? 'Chưa gán dự án', style: AppTypography.header),
          AcademicProgress(
            value: g.integer('progress'),
            label: 'Tiến độ nhóm (ghi nhận)',
          ),
          if (g.memberIds.length > limit)
            Text(
              'Vượt giới hạn · Không thể thêm thành viên',
              style: AppTypography.body.copyWith(color: AppColors.amber),
            ),
          AppMetaGrid(
            items: [
              ('Thành viên', '${g.memberIds.length}/$limit'),
              ('Chờ đánh giá', '${g.integer('pendingReviews')} tài liệu'),
              (
                'Hoạt động mới',
                ((snapshot.data['presentation'] as Map)['activities']
                            as Map)[g.id]
                        ?.toString() ??
                    g.text('lastActivity'),
              ),
            ],
          ),
          Row(
            spacing: AppSpacing.s,
            children: [
              Expanded(
                child: AppButton(
                  label: 'Quản lý nhóm',
                  variant: AppButtonVariant.secondary,
                  onPressed: () =>
                      AppNavigation.open(context, '/groups/${g.id}'),
                ),
              ),
              Expanded(
                child: AppButton(
                  label: p == null ? 'Gán dự án' : 'Xem dự án',
                  variant: AppButtonVariant.secondary,
                  onPressed: () => AppNavigation.open(
                    context,
                    p == null ? '/groups/${g.id}' : '/projects/${p.id}',
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class AcademicProgress extends StatelessWidget {
  const AcademicProgress({required this.value, this.label = '', super.key});
  final int value;
  final String label;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    spacing: AppMetrics.statGap,
    children: [
      if (label.isNotEmpty)
        Row(
          children: [
            Expanded(child: Text(label, style: AppTypography.muted)),
            Text('$value%', style: AppTypography.strong),
          ],
        ),
      LinearProgressIndicator(
        value: value.clamp(0, 100) / 100,
        color: AppColors.brand,
        backgroundColor: AppColors.brandSoft,
        minHeight: AppMetrics.progressTrack,
        borderRadius: BorderRadius.circular(AppSpacing.s),
      ),
    ],
  );
}
