import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/app_navigation.dart';
import '../../models/academic/academic_models.dart';
import '../../viewmodels/academic/academic_form_view_model.dart';
import '../../theme/app_spacing.dart';
import '../../theme/app_typography.dart';
import '../../theme/app_metrics.dart';
import '../../theme/app_colors.dart';
import '../../widgets/app_academic_layout.dart';
import '../../widgets/app_card.dart';
import '../../widgets/app_badge.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_icon.dart';
import '../../widgets/app_states.dart';
import 'course_screens.dart';
import 'widgets/academic_page.dart';
import 'widgets/academic_form_sheet.dart';
import 'widgets/class_card.dart';
import 'widgets/lab_editor.dart';

/// Ba tab cấu hình/Lab/lớp của đợt; bản nháp cấu hình chỉ lưu khi nhấn nút.
class OfferingDetailScreen extends StatefulWidget {
  const OfferingDetailScreen({required this.offeringId, super.key});
  final String offeringId;
  @override
  State<OfferingDetailScreen> createState() => _OfferingDetailScreenState();
}

class _OfferingDetailScreenState extends State<OfferingDetailScreen> {
  int tab = 0;
  @override
  Widget build(BuildContext context) => AcademicPage(
    path: '/course-offerings/${widget.offeringId}',
    builder: (s) {
      final o = s.offering(widget.offeringId);
      if (o == null) {
        return [const AppEmptyState(title: 'Không tìm thấy đợt môn học')];
      }
      final c = s.course(o.courseId);
      return [
        AcademicBackLink('Chi tiết môn học', '/courses/${o.courseId}'),
        AppPageHeading(
          eyebrow: 'HỌC KỲ ${s.semester(o.semesterId)?.name.toUpperCase()}',
          title: '${c?.code} · ${c?.name}',
          aside: ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: AppMetrics.headingAsideWidth,
            ),
            child: AppBadge(
              '${s.offeringClasses(o).length} lớp đang học',
              tone: 'brand',
            ),
          ),
        ),
        AppTabs(
          labels: const ['Cấu hình', 'Lab', 'Lớp'],
          selected: tab,
          onChanged: (i) => setState(() => tab = i),
        ),
        if (tab == 0) OfferingConfiguration(key: ValueKey(o.id), offering: o),
        if (tab == 1)
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            spacing: AppSpacing.s,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.s),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  spacing: AppMetrics.statGap,
                  children: [
                    Text(
                      'Cấu trúc Lab & Deliverables',
                      style: AppTypography.sectionHeading,
                    ),
                    Text(
                      'Thao tác Lab được lưu ngay.',
                      style: AppTypography.muted,
                    ),
                  ],
                ),
              ),
              LabEditor(offering: o, snapshot: s),
            ],
          ),
        if (tab == 2)
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            spacing: AppSpacing.m,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: AppSpacing.l),
                child: Row(
                  spacing: AppSpacing.s,
                  children: [
                    Expanded(
                      child: Text(
                        'Các lớp thuộc đợt này',
                        style: AppTypography.sectionHeading,
                      ),
                    ),
                    SizedBox(
                      width: AppMetrics.compactActionWidth,
                      child: AppButton(
                        label: 'Thêm lớp',
                        compact: true,
                        icon: const AppIcon('plus', size: AppMetrics.formIcon),
                        onPressed: () => showAcademicForm(
                          context,
                          const AcademicFormSpec('class'),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              if (s.offeringClasses(o).isEmpty)
                const AppCard(
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: AppSpacing.xl),
                    child: Text(
                      'Chưa có lớp nào được tạo cho đợt học này. Bấm "Thêm lớp" để tạo lớp mới.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              for (final room in s.offeringClasses(o))
                AcademicClassCard(room: room, snapshot: s, offeringStyle: true),
            ],
          ),
      ];
    },
  );
}

/// Tái sử dụng schema form trong card nội tuyến để tránh hai logic lưu cấu hình.
class OfferingConfiguration extends ConsumerStatefulWidget {
  const OfferingConfiguration({required this.offering, super.key});
  final CourseOffering offering;
  @override
  ConsumerState<OfferingConfiguration> createState() =>
      _OfferingConfigurationState();
}

class _OfferingConfigurationState extends ConsumerState<OfferingConfiguration> {
  late final spec = AcademicFormSpec(
    'offering',
    courseId: widget.offering.courseId,
    data: widget.offering.toJson(),
  );
  bool saved = false;
  @override
  Widget build(BuildContext context) {
    final state = ref.watch(academicFormProvider(spec));
    final vm = ref.read(academicFormProvider(spec).notifier);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        spacing: AppSpacing.m,
        children: [
          Container(
            padding: const EdgeInsets.only(bottom: AppSpacing.m),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: AppColors.line)),
            ),
            child: Row(
              children: [
                const AppIcon('school', color: AppColors.brand),
                const SizedBox(width: AppSpacing.s),
                Expanded(
                  child: Text('Cấu hình', style: AppTypography.emptyTitle),
                ),
                AppButton(
                  label: saved ? 'Đã lưu' : 'Lưu cấu hình',
                  compact: true,
                  icon: const AppIcon('save', size: AppMetrics.formIcon),
                  loading: state.saving,
                  onPressed: vm.invalid != null
                      ? null
                      : () async {
                          if (await vm.save() && mounted) {
                            setState(() => saved = true);
                          }
                        },
                ),
              ],
            ),
          ),
          Text('Nhấn Lưu để áp dụng thay đổi.', style: AppTypography.muted),
          for (final f in vm.fields)
            AcademicFieldView(
              key: ValueKey(f.key),
              field: f,
              value: vm.value(f.key),
              onChanged: (v) {
                setState(() => saved = false);
                vm.set(f.key, v);
              },
            ),
          if (state.saveError.isNotEmpty)
            AppNotice(state.saveError, error: true),
          AppButton(
            label: 'Quản lý bộ quy tắc môn học',
            variant: AppButtonVariant.secondary,
            onPressed: () => AppNavigation.open(
              context,
              '/courses/${widget.offering.courseId}',
            ),
          ),
        ],
      ),
    );
  }
}
