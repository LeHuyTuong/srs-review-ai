import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/app_navigation.dart';
import '../../theme/app_metrics.dart';
import '../../theme/app_spacing.dart';
import '../../viewmodels/dashboard/dashboard_view_model.dart';
import '../../widgets/app_bottom_navigation.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_states.dart';
import '../../widgets/mobile_header.dart';
import 'widgets/dashboard_heading.dart';
import 'widgets/dashboard_stats.dart';
import 'widgets/dashboard_tasks.dart';
import 'widgets/dashboard_secondary_sections.dart';

/// View Tổng quan chỉ quan sát state và chuyển tương tác đến ViewModel/router.
class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dashboardViewModelProvider);
    final viewModel = ref.read(dashboardViewModelProvider.notifier);
    void open(String path) => AppNavigation.open(context, path);
    return Scaffold(
      appBar: MobileHeader(onHome: () => open('/dashboard')),
      bottomNavigationBar: AppBottomNavigation(
        path: '/dashboard',
        onNavigate: open,
      ),
      body: state.when(
        loading: () => const AppLoadingState(),
        error: (error, stack) => Padding(
          padding: const EdgeInsets.all(AppSpacing.pagePadding),
          child: Center(child: AppErrorState(onRetry: viewModel.retry)),
        ),
        data: (data) => SingleChildScrollView(
          key: const PageStorageKey('dashboard-scroll'),
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(
                maxWidth: AppMetrics.contentMaxWidth,
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  AppSpacing.pagePadding,
                  AppSpacing.pageTop,
                  AppSpacing.pagePadding,
                  AppSpacing.xxl,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  spacing: AppSpacing.l,
                  children: [
                    DashboardHeading(
                      state: data,
                      onSemesterChanged: viewModel.selectSemester,
                    ),
                    if (data.isEmpty)
                      AppEmptyState(
                        title: 'Chưa có dữ liệu tổng quan',
                        action: AppButton(
                          label: 'Tải lại',
                          onPressed: viewModel.retry,
                        ),
                      )
                    else ...[
                      DashboardStats(stats: data.stats),
                      AppButton(
                        label: 'Mở đánh giá',
                        onPressed: () => open('/reviews'),
                      ),
                      DashboardTasks(state: data, onNavigate: open),
                      DashboardSecondarySections(state: data, onNavigate: open),
                    ],
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
