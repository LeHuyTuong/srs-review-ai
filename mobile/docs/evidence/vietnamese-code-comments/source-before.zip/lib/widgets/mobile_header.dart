import 'package:flutter/material.dart';

import '../theme/app_colors.dart';
import '../theme/app_metrics.dart';
import '../theme/app_spacing.dart';
import '../theme/app_typography.dart';
import 'app_icon.dart';

/// Header mobile căn trái theo React; Scaffold cấp phần safe area phía trên.
class MobileHeader extends StatelessWidget implements PreferredSizeWidget {
  const MobileHeader({required this.onHome, super.key});
  final VoidCallback onHome;
  @override
  Size get preferredSize =>
      const Size.fromHeight(AppSpacing.headerHeight + AppMetrics.border);

  @override
  Widget build(BuildContext context) => Material(
    color: AppColors.white,
    child: SafeArea(
      bottom: false,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            height: AppSpacing.headerHeight,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.pagePadding,
              ),
              child: Align(
                alignment: Alignment.centerLeft,
                child: InkWell(
                  onTap: onHome,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(
                      minHeight: AppSpacing.tapMin,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const AppIcon(
                          'files',
                          size: AppMetrics.iconLarge,
                          color: AppColors.brand,
                        ),
                        const SizedBox(width: AppMetrics.gridGap),
                        Flexible(
                          child: Text(
                            'SRS Đánh giá AI',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.header,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          const Divider(
            height: AppMetrics.border,
            thickness: AppMetrics.border,
            color: AppColors.line,
          ),
        ],
      ),
    ),
  );
}
