import 'package:flutter/material.dart';

/// Stable editing identity: provider updates never replace a focused field.
class AppSearchField extends StatefulWidget {
  const AppSearchField({
    required this.value,
    required this.onChanged,
    required this.decoration,
    this.style,
    super.key,
  });
  final String value;
  final ValueChanged<String> onChanged;
  final InputDecoration decoration;
  final TextStyle? style;
  @override
  State<AppSearchField> createState() => _AppSearchFieldState();
}

class _AppSearchFieldState extends State<AppSearchField> {
  late final controller = TextEditingController(text: widget.value);
  @override
  void didUpdateWidget(covariant AppSearchField oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Only synchronize explicit external clear/restore; preserve caret/composing
    // on ordinary keystrokes, where controller and provider already agree.
    if (controller.text != widget.value) {
      controller.value = TextEditingValue(
        text: widget.value,
        selection: TextSelection.collapsed(offset: widget.value.length),
      );
    }
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => TextFormField(
    controller: controller,
    style: widget.style,
    decoration: widget.decoration,
    onChanged: widget.onChanged,
  );
}
