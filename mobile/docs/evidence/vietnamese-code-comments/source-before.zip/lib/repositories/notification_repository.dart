import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/academic/academic_models.dart';
import '../app/session.dart';

abstract interface class NotificationRepository {
  Future<List<AcademicRecord>> load();
}

class FakeNotificationRepository implements NotificationRepository {
  FakeNotificationRepository(this.bundle);
  final AssetBundle bundle;
  @override
  Future<List<AcademicRecord>> load() async =>
      (jsonDecode(await bundle.loadString('assets/fixtures/notifications.json'))
              as List)
          .map((v) => AcademicRecord(v as AcademicJson))
          .where(
            (n) =>
                !RegExp(
                  r'(?:yêu cầu|đề nghị) tham gia (?:lớp|nhóm)|join (?:class|group) request',
                  caseSensitive: false,
                ).hasMatch(n.text('title')) &&
                !(RegExp(
                      r'tham gia|join',
                      caseSensitive: false,
                    ).hasMatch(n.text('title')) &&
                    RegExp(
                      r'lớp|nhóm|class|group',
                      caseSensitive: false,
                    ).hasMatch(n.text('title')) &&
                    RegExp(
                      r'chờ.*duyệt|chờ.*phê duyệt|yêu cầu.*duyệt|pending|awaiting approval',
                      caseSensitive: false,
                    ).hasMatch(n.text('title'))),
          )
          .toList(growable: false);
}

final notificationRepositoryProvider = Provider<NotificationRepository>((ref) {
  ref.watch(sessionScopeProvider);
  return FakeNotificationRepository(rootBundle);
});
final notificationsProvider = FutureProvider<List<AcademicRecord>>(
  (ref) => ref.watch(notificationRepositoryProvider).load(),
);

bool notificationMatches(AcademicRecord n, int tab) => switch (tab) {
  1 => n.flag('unread'),
  2 => ['file-up', 'badge-check'].contains(n.text('kind')),
  3 => n.text('kind') == 'clock',
  4 => n.text('title').contains('Đánh giá AI'),
  _ => true,
};
