import '../../models/academic/academic_models.dart';

/// First migrated DTO slice. Preserve unknown legacy fields without trusting
/// primitive casts at the data edge. Remaining aggregates migrate independently.
class CourseDto {
  CourseDto._(this._record);
  final AcademicRecord _record;
  String get id => _record.id;
  String get code => _record.text('code');
  String get name => _record.name;
  AcademicJson toJson() => _record.toJson();
  factory CourseDto.fromJson(
    Object? value, {
    bool requireId = true,
    AcademicErrorCode errorCode = AcademicErrorCode.invalidData,
  }) {
    if (value is! Map<String, dynamic> ||
        value['code'] is! String ||
        (value['code'] as String).trim().isEmpty ||
        value['name'] is! String ||
        (value['name'] as String).trim().isEmpty ||
        (value['id'] != null && value['id'] is! String) ||
        (requireId && (value['id'] as String? ?? '').isEmpty)) {
      throw AcademicFailure(
        'Dữ liệu môn học không hợp lệ. Nhập mã và tên môn học.',
        code: errorCode,
      );
    }
    return CourseDto._(
      AcademicRecord({
        ...value,
        'code': (value['code'] as String).trim().toUpperCase(),
        'name': (value['name'] as String).trim(),
      }),
    );
  }
}

/// Explicit create/update intent prevents an insertion from becoming an upsert.
class CourseMutation {
  CourseMutation({
    required this.course,
    required this.id,
    required this.create,
  });
  final CourseDto course;
  final String id;
  final bool create;
  AcademicSnapshot apply(AcademicSnapshot current) {
    final existing = current.course(id);
    if (create && existing != null) {
      throw const AcademicFailure(
        'ID môn học đã tồn tại. Vui lòng thử lại.',
        code: AcademicErrorCode.conflict,
      );
    }
    if (!create && existing == null) {
      throw const AcademicFailure(
        'Không tìm thấy môn học.',
        code: AcademicErrorCode.notFound,
      );
    }
    if (current.courses.any(
      (c) => c.id != id && c.code.trim().toUpperCase() == course.code,
    )) {
      throw const AcademicFailure('Mã môn đã tồn tại.');
    }
    final row = {...?existing?.toJson(), ...course.toJson(), 'id': id};
    return current.replaceCollection('courses', [
      for (final old in current.courses)
        if (old.id == id) row else old.toJson(),
      if (create) row,
    ]);
  }
}

/// Additive command seam; legacy aggregate commands remain compatible.
/// A real adapter must authorize UID/scope, check expected version and execute
/// this intent atomically on the server, never trust a client snapshot upload.
abstract interface class CourseCommandRepository {
  Future<AcademicSnapshot> commitCourse(
    CourseMutation command, {
    required int expectedRevision,
  });
}

abstract final class AcademicSnapshotCodec {
  static AcademicSnapshot decode(Object? value) {
    if (value is! Map<String, dynamic> || value['courses'] is! List) {
      throw const AcademicFailure(
        'Dữ liệu học vụ không hợp lệ.',
        code: AcademicErrorCode.invalidData,
      );
    }
    for (final row in value['courses'] as List) {
      CourseDto.fromJson(row);
    }
    return AcademicSnapshot(value);
  }
}
