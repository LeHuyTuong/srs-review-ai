/// Hợp đồng thiết bị cho import/clipboard; ViewModel không phụ thuộc plugin native.
abstract interface class StudentDeviceGateway {
  Future<({String name, String? csv})?> pick();
  Future<void> copy(String text);
}
