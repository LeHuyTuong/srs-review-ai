import '../../models/academic/academic_models.dart';

/// Hợp đồng kho học vụ; adapter Firestore sau này không xuất hiện trong widget.
abstract interface class AcademicRepository {
  Future<AcademicSnapshot> load();
  Future<AcademicSnapshot> commit(
    AcademicSnapshot next, {
    required int expectedRevision,
  });
}
