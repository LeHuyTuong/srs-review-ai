import '../models/counter_state.dart';
import '../services/demo_counter_service.dart';

/// Hợp đồng dữ liệu counter phục vụ kiểm chứng dependency injection foundation.
abstract interface class CounterRepository {
  CounterState load();
  CounterState increment();
}

/// Chuyển bộ nhớ tạm thành snapshot counter cho ViewModel.
class DemoCounterRepository implements CounterRepository {
  DemoCounterRepository(this._service);

  final DemoCounterService _service;

  @override
  CounterState load() => CounterState(count: _service.read());

  @override
  CounterState increment() {
    _service.write(_service.read() + 1);
    return load();
  }
}
