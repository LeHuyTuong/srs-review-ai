import '../../models/dashboard/dashboard_snapshot.dart';
import '../../services/dashboard/fake_dashboard_service.dart';
import 'dashboard_repository.dart';

/// Chuyển dữ liệu fixture sang model, không cấp quyền hoặc quyết định review.
class FakeDashboardRepository implements DashboardRepository {
  const FakeDashboardRepository(this._service);
  final FakeDashboardService _service;

  @override
  Future<DashboardSnapshot> load() async =>
      DashboardSnapshot.fromJson(await _service.load());
}
