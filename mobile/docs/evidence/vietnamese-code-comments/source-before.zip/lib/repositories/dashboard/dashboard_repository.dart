import '../../models/dashboard/dashboard_snapshot.dart';

/// Hợp đồng độc lập nguồn dữ liệu để thay fake bằng repository thật sau này.
abstract interface class DashboardRepository {
  Future<DashboardSnapshot> load();
}
