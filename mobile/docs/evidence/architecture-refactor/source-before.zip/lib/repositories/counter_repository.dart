import '../models/counter_state.dart';
import '../services/demo_counter_service.dart';

// Hợp đồng dữ liệu bộ đếm phục vụ kiểm chứng cách cung cấp phụ thuộc nền tảng.
abstract interface class CounterRepository {
  CounterState load();
  CounterState increment();
}

// Chuyển giá trị bộ nhớ tạm thành trạng thái bộ đếm cho ViewModel.
class DemoCounterRepository implements CounterRepository {
  DemoCounterRepository(this._service);

  final DemoCounterService _service;

  @override
  CounterState load() => CounterState(count: _service.read());

  @override
  CounterState increment() {
    _service.write(_service.read() + 1);
    return load();
  }
}
