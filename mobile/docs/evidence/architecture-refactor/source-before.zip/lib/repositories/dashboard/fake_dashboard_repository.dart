import '../../models/dashboard/dashboard_snapshot.dart';
import '../../services/dashboard/fake_dashboard_service.dart';
import 'dashboard_repository.dart';

// Chuyển dữ liệu mẫu sang mô hình Tổng quan, không cấp quyền hay quyết định đánh giá.
class FakeDashboardRepository implements DashboardRepository {
  const FakeDashboardRepository(this._service);
  final FakeDashboardService _service;

  @override
  Future<DashboardSnapshot> load() async =>
      DashboardSnapshot.fromJson(await _service.load());
}
