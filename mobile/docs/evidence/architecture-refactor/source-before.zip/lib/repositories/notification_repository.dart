import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../models/academic/academic_models.dart';
import '../app/session.dart';

// Hợp đồng tải thông báo để màn hình không phụ thuộc trực tiếp vào dữ liệu mẫu.
abstract interface class NotificationRepository {
  Future<List<AcademicRecord>> load();
}

// Đọc thông báo mẫu và loại các yêu cầu duyệt tham gia lớp, nhóm ngoài luồng Mobile hiện tại.
class FakeNotificationRepository implements NotificationRepository {
  FakeNotificationRepository(this.bundle);
  final AssetBundle bundle;
  @override
  Future<List<AcademicRecord>> load() async =>
      (jsonDecode(await bundle.loadString('assets/fixtures/notifications.json'))
              as List)
          .map((v) => AcademicRecord(v as AcademicJson))
          .where(
            (n) =>
                !RegExp(
                  r'(?:yêu cầu|đề nghị) tham gia (?:lớp|nhóm)|join (?:class|group) request',
                  caseSensitive: false,
                ).hasMatch(n.text('title')) &&
                !(RegExp(
                      r'tham gia|join',
                      caseSensitive: false,
                    ).hasMatch(n.text('title')) &&
                    RegExp(
                      r'lớp|nhóm|class|group',
                      caseSensitive: false,
                    ).hasMatch(n.text('title')) &&
                    RegExp(
                      r'chờ.*duyệt|chờ.*phê duyệt|yêu cầu.*duyệt|pending|awaiting approval',
                      caseSensitive: false,
                    ).hasMatch(n.text('title'))),
          )
          .toList(growable: false);
}

// Tạo lại nguồn thông báo theo phiên để không tái sử dụng dữ liệu phiên trước.
final notificationRepositoryProvider = Provider<NotificationRepository>((ref) {
  ref.watch(sessionScopeProvider);
  return FakeNotificationRepository(rootBundle);
});
// Đưa trạng thái tải và lỗi thông báo lên giao diện; làm mới provider khi người dùng thử lại.
final notificationsProvider = FutureProvider<List<AcademicRecord>>(
  (ref) => ref.watch(notificationRepositoryProvider).load(),
);

// Lọc theo thẻ đang chọn; nhóm đánh giá dựa vào loại biểu tượng, nhóm AI dựa vào tiêu đề.
bool notificationMatches(AcademicRecord n, int tab) => switch (tab) {
  1 => n.flag('unread'),
  2 => ['file-up', 'badge-check'].contains(n.text('kind')),
  3 => n.text('kind') == 'clock',
  4 => n.text('title').contains('Đánh giá AI'),
  _ => true,
};
