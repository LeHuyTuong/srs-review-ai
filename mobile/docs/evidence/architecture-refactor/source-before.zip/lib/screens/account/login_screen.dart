import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../app/session.dart';
import '../../theme/app_spacing.dart';
import '../../theme/app_typography.dart';
import '../../widgets/app_academic_layout.dart';
import '../../widgets/app_button.dart';
import '../../widgets/app_icon.dart';
import '../../widgets/app_badge.dart';
import '../../theme/app_colors.dart';

// Màn đăng nhập dành cho Supervisor; biểu mẫu kiểm tra đầu vào trước khi tạo phiên mô phỏng.
class LoginScreen extends ConsumerStatefulWidget {
  const LoginScreen({super.key});
  @override
  ConsumerState<LoginScreen> createState() => _LoginState();
}

class _LoginState extends ConsumerState<LoginScreen> {
  // Thông tin điền sẵn chỉ phục vụ đăng nhập mô phỏng; dự kiến thay bằng Google Sign-In.
  final email = TextEditingController(text: 'an.nguyen@university.edu.vn');
  final password = TextEditingController(text: 'password');
  final form = GlobalKey<FormState>();
  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    body: SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.pagePadding),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 480),
            child: Form(
              key: form,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                spacing: AppSpacing.l,
                children: [
                  Row(
                    spacing: AppSpacing.s,
                    children: [
                      const AppIcon('files', size: 28, color: AppColors.brand),
                      Text('SRS Review AI', style: AppTypography.header),
                      const AppBadge('AI', tone: 'olive'),
                    ],
                  ),
                  const AppPageHeading(
                    title: 'Đăng nhập giảng viên',
                    description: 'Đánh giá tài liệu, quản lý lớp và dự án.',
                  ),
                  TextFormField(
                    controller: email,
                    keyboardType: TextInputType.emailAddress,
                    autofillHints: const [AutofillHints.email],
                    decoration: const InputDecoration(labelText: 'Email'),
                    validator: (v) =>
                        v == null ||
                            v.trim().isEmpty ||
                            !RegExp(r'^[^\s@]+@[^\s@]+\.[^\s@]+$')
                                .hasMatch(v.trim())
                        ? 'Nhập email hợp lệ.'
                        : null,
                  ),
                  TextFormField(
                    controller: password,
                    obscureText: true,
                    autofillHints: const [AutofillHints.password],
                    decoration: const InputDecoration(labelText: 'Mật khẩu'),
                    validator: (v) => v == null || v.isEmpty
                        ? 'Vui lòng nhập mật khẩu.'
                        : null,
                  ),
                  AppButton(
                    label: 'Đăng nhập',
                    onPressed: () {
                      if (form.currentState!.validate()) {
                        ref
                            .read(sessionProvider.notifier)
                            .signIn('supervisor', email.text, password.text);
                      }
                    },
                  ),
                  const Text(
                    'Đăng nhập mô phỏng để kiểm thử. '
                    'Sẽ thay bằng Google Sign-In khi tích hợp Firebase.',
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    ),
  );
}
