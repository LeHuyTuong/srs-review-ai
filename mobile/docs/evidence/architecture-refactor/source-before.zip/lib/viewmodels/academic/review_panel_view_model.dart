import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../models/academic/academic_models.dart';
import 'academic_view_model.dart';
import 'review_actions.dart';
import '../../app/session.dart';

// Trạng thái tương tác AI theo yêu cầu đánh giá, tách riêng kết quả lưu trong Repository.
class ReviewPanelState {
  const ReviewPanelState({
    this.attentionOnly = true,
    this.expanded = const {},
    this.added = const {},
    this.error = '',
  });
  final bool attentionOnly;
  final Set<String> expanded, added;
  final String error;
}

// Giữ phần mở rộng và phát hiện đã thêm theo yêu cầu; đổi phiên sẽ khởi tạo lại trạng thái tương tác.
final reviewPanelProvider = NotifierProvider.autoDispose
    .family<ReviewPanelViewModel, ReviewPanelState, String>(
      ReviewPanelViewModel.new,
    );

// Điều phối tương tác AI và hiển thị lỗi; kết quả và nhật ký lưu ở kho học vụ chung.
class ReviewPanelViewModel extends Notifier<ReviewPanelState> {
  ReviewPanelViewModel(this.id);
  final String id;
  @override
  ReviewPanelState build() {
    ref.watch(sessionScopeProvider);
    return const ReviewPanelState();
  }

  void attention(bool value) => state = ReviewPanelState(
    attentionOnly: value,
    expanded: state.expanded,
    added: state.added,
  );
  void expand(Set<String> values) => state = ReviewPanelState(
    attentionOnly: state.attentionOnly,
    expanded: values,
    added: state.added,
  );
  // Xóa lỗi cũ trước khi chạy lại; chỉ cập nhật giao diện nếu phiên khởi chạy còn hiệu lực.
  Future<void> run() async {
    final scope = ref.read(sessionScopeProvider);
    state = ReviewPanelState(
      attentionOnly: state.attentionOnly,
      expanded: state.expanded,
      added: state.added,
    );
    try {
      await ref.read(academicViewModelProvider.notifier).runEvaluation(id);
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: state.added,
        );
      }
    } catch (e) {
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: state.added,
          error: e is AcademicFailure
              ? e.message
              : 'Không thể tạo kết quả. Vui lòng thử lại.',
        );
      }
    }
  }

  // Trong vòng đời bảng AI, phát hiện đã thêm thành công không được thêm lần nữa.
  // Chỉ đánh dấu đã thêm sau khi lưu phản hồi nháp thành công.
  Future<void> addFinding(AcademicRecord f) async {
    final scope = ref.read(sessionScopeProvider);
    if (state.added.contains(f.id)) return;
    try {
      await ref.read(academicViewModelProvider.notifier).addFeedback(id, {
        'severity': f.text('level') == 'error' ? 'Major' : 'Minor',
        'category': f.text('category'),
        'pageRef': f.text('pageRef'),
        'message': f.text('message'),
      });
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: {...state.added, f.id},
        );
      }
    } catch (e) {
      if (ref.mounted && scope.active) {
        state = ReviewPanelState(
          attentionOnly: state.attentionOnly,
          expanded: state.expanded,
          added: state.added,
          error: e is AcademicFailure ? e.message : 'Không thể thêm phản hồi.',
        );
      }
    }
  }
}
