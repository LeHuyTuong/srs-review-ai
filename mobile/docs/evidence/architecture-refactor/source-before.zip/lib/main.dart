import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app/app.dart';

// Khởi tạo phạm vi Riverpod cho toàn bộ ứng dụng trước khi dựng màn hình đầu tiên.
void main() {
  runApp(const ProviderScope(child: SrsReviewApp()));
}
