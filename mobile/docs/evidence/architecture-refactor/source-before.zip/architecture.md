# Lab 3 — MVVM + Riverpod, phases 1–2

Ngày: 24/10/2026. Riverpod `^3.4.3`, phiên bản được khóa trong pubspec.lock. Điểm vào hiện tại là Supervisor Dashboard. Chưa có backend/Firebase hoặc xác thực thật. Demo counter foundation được giữ lại để kiểm thử, không còn là home.

## Layers và trách nhiệm

| Folder | Trách nhiệm | Triển khai hiện tại |
|---|---|---|
| lib/app | Composition root, app widget, dependency injection và navigation | app.dart, providers.dart, app_navigation.dart |
| lib/theme | Tokens tập trung và ThemeData, không chứa business state | AppColors, AppTypography, AppSpacing, AppRadius, AppTheme |
| lib/models/dashboard | Snapshot nguồn, lớp/nhóm/dự án, request và state bất biến | DashboardSnapshot, DashboardState |
| lib/viewmodels/dashboard | Tải dữ liệu, kiểm tra ID học kỳ, tính thống kê và giới hạn phạm vi | DashboardViewModel + AsyncNotifierProvider |
| lib/repositories/dashboard | Hợp đồng dữ liệu và mapping; che giấu nguồn dữ liệu | DashboardRepository + FakeDashboardRepository |
| lib/services/dashboard | Đọc fixture qua AssetBundle | FakeDashboardService |
| lib/screens/dashboard | View cấp màn hình và các phần UI riêng của feature | DashboardScreen + widgets/heading, stats, tasks, secondary sections |
| lib/widgets | Shared components nhận dữ liệu/callback, không tính nghiệp vụ | Header, bottom nav, button, badge, card, stat, disclosure, loading/empty/error |

`main.dart` chỉ bootstrap `ProviderScope(child: SrsReviewApp())`. Providers được khai báo thủ công; không thêm code generator vào foundation.

## Dependency rules

1. Screens → ViewModels + Widgets + Theme; không gọi Service/Repository trực tiếp.
2. Widgets nhận giá trị/callback, không đọc nguồn dữ liệu; không chứa business rules.
3. ViewModels → repository contract + Models + Riverpod. Không giữ BuildContext, không import screen/theme hay concrete service.
4. Repository → Models + Services; hợp đồng không lộ kiểu Flutter, Riverpod hay storage-specific types.
5. Services không import ViewModel/View/App; model không import layer khác.
6. App là composition root được phép tạo concrete implementations. `app/providers.dart` là điểm khai báo DI, không chứa View/UI; ViewModel chỉ tham chiếu provider trả về contract.
7. Không singleton mutable toàn cục. Service/repository được tạo trong scope; ProviderContainer mới có state riêng. Không tạo một ProviderScope riêng cho từng screen trong cùng ứng dụng.
8. Feature SRS tương lai giữ đúng hướng dependency trên; khi code lớn lên có thể gom theo feature mà không đảo chiều layer.

## Luồng dữ liệu Dashboard

```mermaid
flowchart LR
  View[DashboardScreen] -->|selectSemester / retry| VM[DashboardViewModel]
  VM -->|DashboardRepository contract| Repo[FakeDashboardRepository]
  Repo --> Service[FakeDashboardService]
  Service -->|AssetBundle / JSON fixture| Repo
  Repo -->|immutable DashboardSnapshot| VM
  VM -->|provider notifies / ref.watch| View
  View --> Widget[Shared widgets]
```

`build()` tải snapshot qua repository. AsyncValue phân biệt loading/error/data; học kỳ không có yêu cầu hiện empty state của việc cần làm. Chọn học kỳ chỉ tính lại dữ liệu trong ViewModel, không tải lại JSON. ID không tồn tại bị bỏ qua. Retry invalidate vòng tải; tắt automatic retry của Riverpod để người dùng chủ động thử lại, tránh màn lỗi tự nhấp nháy.

Quan hệ thống kê giữ theo source: học kỳ → lớp → nhóm → dự án. Chỉ lớp active dùng cho số môn/lớp theo dõi. Chỉ dự án active được tính vào tập dự án cần xử lý; dùng tập ID để không đếm trùng nhiều request/nhắc việc. Request waiting/inReview vẫn theo bộ lọc học kỳ như React, không tự loại vì một trạng thái khác.

Fixture `assets/fixtures/dashboard.json` được trích từ các store khởi tạo React (không đọc dữ liệu người dùng đã lưu). `tools/extract-react-fixture.mjs` chỉ đọc modules nguồn và dùng localStorage giả trong bộ nhớ để xuất fixture về dự án Flutter. Dữ liệu này chỉ phục vụ UI và tương tác phase 1; không phải dữ liệu/rubric chính thức hoặc backend Lab 3 cuối cùng.

CTA và bottom nav dùng Navigator với route giữ trong RouteSettings. Phase 2 đã nối sáu route Course/Class/Rule Set trong traceability tới màn thực. Các route GroupDetail/ProjectDetail/ReviewDetail và phần còn lại vẫn tới `NavigationDestinationScreen`, hiển thị rõ chức năng đang được chuẩn bị. Android Back giữ state/bộ lọc; header và tab Tổng quan về route gốc. Không cài router thứ hai.

Các feature được chia thành thư mục con `dashboard/` trong các layer foundation hiện có. Shared widgets và tokens vẫn dùng chung trong `lib/widgets/`, `lib/theme/`; không tạo bộ core/data/domain mới song song.

## Mở rộng cho Lab 3

- Repository SRS có contract riêng cho reviews/academic/session. Tách document status, AI evaluation và Supervisor decision theo mapping, không gom thành một status.
- AsyncNotifier/AsyncValue cho dữ liệu bất đồng bộ: loading/error/data; danh sách data rỗng được View hiển thị empty state. Lỗi mutation giữ nội dung và draft thay vì xóa dữ liệu đang đọc.
- Dùng provider family theo ID. Hủy listener khi dispose; chống kết quả cũ cập nhật vào context/version mới; khóa lệnh gửi trùng.
- Repository chịu trách nhiệm mutation nhất quán request/version/feedback/audit/notification. ViewModel không sửa nhiều kho độc lập từ View.
- Session và role guard triển khai ở phase xác thực; không giả bộ role selection là xác thực thật. Chưa cài go_router; phase 1 chỉ dùng Navigator cho Dashboard và điểm dừng các route ngoài phạm vi.
- Không chuyển hàng loạt screen, gọi AI thật, Firebase hoặc dùng WebView bọc React.

## Kiểm tra

- Dashboard ViewModel test: số liệu đối chiếu React, thay repository bằng override, học kỳ/ID lạ, loading/error/retry và không tải lại nguồn khi lọc.
- Widget test: 360/390/412dp với Inter thật, bộ chọn học kỳ căn phải, CTA, bottom navigation, Back giữ state, loading/error/retry và chặn nút disabled/loading.
- Counter foundation vẫn có test command/repository và hai ProviderContainer độc lập.
- `flutter analyze` sạch, tổng 12 test đạt. Integration test trên Pixel 4a ở cả 3 chiều rộng đều đạt, có ảnh thực và số đo; xem [báo cáo phase 1](phase1-ui-report.md).

Nguồn API: [Riverpod 3](https://riverpod.dev/docs/whats_new). Hướng chuyển đổi và inventory: [React mapping](react-flutter-mapping.md), [design traceability](design-traceability.md).

## Feature học vụ Phase 2

Giữ các layer foundation, thêm thư mục con `academic/` ở models/viewmodels/repositories/services/screens. Course, offering, Class và Rule Set cùng một feature học vụ vì phải kiểm tra các liên kết và phạm vi gán trong cùng lần ghi; không tạo thêm hệ core/data/domain song song.

| Layer | Trách nhiệm Phase 2 |
|---|---|
| Models | Các record bất biến Course/Offering/Class/Rule/Lab/Student/Group, snapshot liên kết; policy thuần Dart cho validation/giới hạn nhóm/clone dependencies |
| ViewModels | AcademicViewModel tải và điều phối command; AcademicFormViewModel giữ draft/validation/lỗi ghi; ClassFilterViewModel giữ filter; StudentEnrollmentViewModel parse/validate/chọn batch |
| Repositories | AcademicRepository contract `load/commit(expectedRevision)`; fake adapter gọi service. StudentDeviceGateway là contract cho bộ chọn tệp/clipboard |
| Services | FakeAcademicService đọc fixture một lần và giữ snapshot trong phiên; StudentImportService bọc plugin native. Không API/Firebase |
| App | providers.dart tạo adapter/service và cung cấp contract, app.dart dispatch sáu route; locale vi cho các điều khiển native |
| Screens/Widgets | Quan sát state, render các trạng thái, chuyển tương tác vào ViewModel; state mở disclosure/tab và controller nhập liệu chỉ là state trình bày |

```mermaid
flowchart LR
  Screen[Course / Class / Rule UI] -->|command / save / retry| VM[Riverpod ViewModels]
  VM --> Policy[AcademicPolicy + immutable models]
  VM --> Contract[AcademicRepository]
  Contract --> Adapter[FakeAcademicRepository]
  Adapter --> Service[FakeAcademicService]
  Service --> Fixture[academic.json + memory]
  VM -->|pick / copy| Device[StudentDeviceGateway]
  Device --> Native[StudentImportService / Android plugins]
  VM -->|AsyncValue / draft state| Screen
```

Một mutation tạo snapshot mới; service so revision trước khi commit. Lỗi giữ dữ liệu đang xem, form giữ draft và cho thử lại. Chặn double-submit; kiểm tra ref.mounted trước khi công bố kết quả sau await. Đóng form hủy listener family/autoDispose. Lưu cấu hình đợt không tự thay labs; editor Lab ghi riêng ngay khi xác nhận. Khi học vụ thay đổi, invalidate DashboardViewModel để thống kê dùng cùng kho, không giữ hai bộ fixture học vụ tách rời.

Rule Set dùng chung, scope Course suy ra từ assignment. Gán rule cấp item trong lớp sao chép cấu trúc kế thừa rồi patch; chỉ thay đúng collection/phạm vi. Lưu rule tăng version và không chỉnh reviewState/DocumentVersion cũ. Đánh giá AI chỉ là đề xuất; phase này không tạo quyết định phê duyệt hoặc luồng Review mới.

Các record giữ trường chưa chuyển qua JSON bất biến để không đánh rơi cấu hình/historical payload khi cập nhật. Contract snapshot hiện phục vụ fake UI: adapter Firestore tương lai phải ánh xạ command thành transaction, kiểm tra quyền ở server và lưu version snapshots; không ghi đè toàn bộ dữ liệu production bằng fixture. Session/auth/backend vẫn là phase riêng. Import/QR/saved filters và giới hạn giả lập được ghi rõ trong [báo cáo Phase 2](phase2-ui-report.md).

Kiểm chứng Phase 2: analyze sạch, 70 test đạt, ba lượt Android 360/390/412dp đạt. ClassOverview dùng cùng snapshot và shared widgets; lọc yêu cầu mở theo `isCompleted` của React (bao gồm quyết định needsRevision), không sửa lịch sử để điều chỉnh thống kê.

## Bổ sung Phase 3 — Group, Project, Review

Giữ nguyên `AcademicRepository` → `FakeAcademicRepository` → `FakeAcademicService` và một `academicViewModelProvider` trong ProviderScope gốc. Không có store Phase 3 riêng, Firebase, HTTP hoặc database trong widget. `management_actions.dart` và `review_actions.dart` là extension điều phối lệnh trên cùng AcademicViewModel; mọi mutation đi qua `mutate` và `expectedRevision` hiện có.

- **Model/policy**: `ManagementQueries` dựng ngữ cảnh Group → Class → Offering → Course/Semester, documents, khóa dependency, review rule snapshot, current versions; `ReviewPolicy` tính kết quả minh họa từ kịch bản React. Record/snapshot đóng băng sâu và giữ trường chưa chuyển. `currentIllustration` là phép chiếu chỉ đọc, không ghi đè legacy evaluations.
- **ViewModel**: `ManagementFormViewModel` dùng lại `AcademicFormSpec`, `AcademicField`, `AcademicFormState`; quản lý nháp/validation/lỗi ghi. `ManagementListViewModel` quản lý phạm vi, OR/AND facets, cascade, tìm kiếm, thời gian, sắp xếp và saved view trong phiên. `ReviewPanelViewModel` quản lý tiêu chí mở/đóng, cần chú ý, thêm finding và lỗi AI.
- **View**: `screens/management/` dùng AcademicPage, cùng header/bottom navigation, form field, modal, card, badge, progress, disclosure và tokens Phase 1–2. Các tab chỉ thay nội dung hiển thị. Widget chuyển thao tác tới ViewModel; không gọi service dữ liệu.
- **Luồng ghi nhóm/dự án**: kiểm tra lớp hoạt động/giới hạn/thành viên/unique group name; ghi đồng thời memberIds, student.groupId và project.members. Tạo/chuyển/xóa dự án cập nhật cả Group.projectId và số đếm lớp. Lưu trữ chỉ đổi trạng thái, không xóa lịch sử.
- **Luồng Review**: resolve snapshot → kiểm tra AI bắt buộc → bắt đầu/phản hồi/quyết định. Quyết định chỉ nhận current version và các ID phản hồi được chọn; official feedback và audit không có lệnh sửa/xóa. needsRevision là completed của lượt. AI ghi loading rồi kết quả theo run token và version; không tự chuyển approved. Phiên bản cũ được trình bày bất biến.
- **Dashboard**: cùng snapshot chiếu live requests/evaluations; mutation invalidate DashboardViewModel. Attention items vẫn là nhắc việc fixture của React; số waiting/inReview/needsRevision lấy trạng thái hiện hành.

Repository Firestore tương lai phải thực hiện transaction tương ứng, xác thực quyền ở server và giữ snapshot bất biến. Fake hiện tại không bảo đảm lưu qua khởi động lại hay đồng bộ nhiều thiết bị. Nội dung tài liệu và AI là minh họa như React; không đọc byte tệp thật. Các route Student/auth ngoài ứng dụng Supervisor hiện tại không được giả lập thành chức năng upload của giảng viên.
